# 🎮 Interactive Features Guide

## Overview

This ATmega328P architecture blueprint goes beyond static diagrams by providing **hands-on interactive simulations** of how each CPU component actually works.

---

## 🧮 Interactive ALU Simulator

### What You Can Do:
- **Input two 8-bit values** (0-255) as operands A and B
- **Select operations**: ADD, SUB, AND, OR, EOR, LSL, LSR, ASR, ROL, ROR
- **Execute and see results** in real-time
- **Watch status flags update**: C (Carry), Z (Zero), N (Negative), V (Overflow), H (Half Carry)

### Learning Points:
- How arithmetic operations work at the bit level
- Why flags are important for conditional branching
- Difference between logical and arithmetic shifts
- How rotate operations preserve bits through carry

### Example Use Cases:
```
Try this:
1. Operand A: 127 (0x7F)
2. Operand B: 1 (0x01)  
3. Operation: ADD
4. Result: 128 (0x80) - Notice N flag sets (negative in signed math)!

Or this:
1. Operand A: 240 (0b11110000)
2. Operand B: 60 (0b00111100)
3. Operation: AND
4. Result: 48 (0b00110000) - Bitwise AND masks bits
```

---

## 📥 Instruction Fetch Simulator

### What You Can Do:
- **Navigate through Flash memory** with PC controls
- **Animate the fetch sequence** step-by-step
- **See the 6-stage process**:
  1. PC points to Flash address
  2. Address sent to Flash memory
  3. Flash outputs 16-bit instruction
  4. Instruction loaded into IR
  5. PC incremented (PC + 1)
  6. Ready for next fetch

### Learning Points:
- How the Program Counter works
- What happens during instruction fetch
- Why instructions are 16 bits wide
- How the 2-stage pipeline allows fetch while executing

### Interactive Elements:
- **Highlighted memory address** shows where PC is pointing
- **Live instruction display** shows what's being fetched
- **Binary breakdown** of the fetched instruction
- **Timing information**: 1 cycle = 62.5ns @ 16MHz

---

## 🔍 Instruction Decoder Simulator

### What You Can Do:
- **Enter any 16-bit hex instruction** (e.g., 0xE000)
- **Decode it instantly** to see:
  - Assembly language representation
  - Instruction type and format
  - Operand fields (Rd, Rr, K)
  - Execution cycles
- **Try quick examples**: LDI, ADD, RET, JMP

### Learning Points:
- How 16-bit instructions encode operations
- What opcode patterns look like
- How operands are embedded in instructions
- Difference between instruction formats

### Example Decodings:

**LDI R16, 42**
```
Hex: 0xE02A
Binary: 1110 0000 0010 1010
Fields:
  - Opcode: 1110 (LDI instruction)
  - Rd: 0000 (R16, using registers R16-R31)
  - K: 00101010 (constant value 42)
Cycles: 1
```

**ADD R16, R17**
```
Hex: 0x0F01
Binary: 0000 1111 0000 0001
Fields:
  - Opcode: 000011 (ADD instruction)
  - Rd: 10000 (R16)
  - Rr: 10001 (R17)
Cycles: 1
```

---

## ⚙️ Control Unit Simulator

### What You Can Do:
- **Select different instructions** (ADD, SUB, LDI, MOV, ST, LD)
- **Generate control signals** for each instruction
- **See exactly what signals** activate each component:
  - Register File controls (read/write enables, port selection)
  - ALU controls (operation type, operand routing)
  - Memory controls (read/write, addressing)
  - Program Counter updates
  - Timing and pipeline info

### Learning Points:
- What the control unit actually does
- How FSM (Finite State Machine) works
- Why different instructions take different cycles
- How components are coordinated

### Example: ADD Instruction

**Control Signals Generated:**
```
Register File:
  ✓ Read Port A: R16
  ✓ Read Port B: R17
  ✓ Write Enable: YES
  ✓ Write Port: R16

ALU:
  ✓ Operation: ADD
  ✓ Operand A Source: Rd
  ✓ Operand B Source: Rr

SREG:
  ✓ Update Flags: C Z N V H S

Program Counter:
  ✓ Action: PC = PC + 1

Memory:
  ✗ Read: NO
  ✗ Write: NO

Timing:
  ⚡ Cycles: 1
  🔄 Pipeline: Execute while fetching next
```

### Why This Matters:
Understanding control signals helps you:
- Optimize assembly code
- Understand timing-critical operations
- Debug hardware-level issues
- Appreciate CPU design complexity

---

## 🎯 How to Use These Tools

### For Beginners:
1. Start with the **ALU simulator** - it's the most visual
2. Try simple operations (ADD, SUB) first
3. Watch how flags change
4. Experiment with bit operations (AND, OR, XOR)

### For Intermediate Users:
1. Use the **Instruction Fetch simulator** to understand the fetch-execute cycle
2. Watch the animation multiple times
3. Understand why it takes 1 cycle
4. See how PC increments

### For Advanced Users:
1. **Decoder simulator**: Enter custom instructions
2. Analyze opcode patterns
3. **Control Unit simulator**: Study signal coordination
4. Understand why hardwired control is faster than microcode

---

## 🔬 Educational Experiments

### Experiment 1: Overflow Detection
```
ALU Simulator:
- Operand A: 200
- Operand B: 100
- Operation: ADD
- Result: 44 (overflow! 300 % 256 = 44)
- Notice: C flag = 1 (carry out)
```

### Experiment 2: Bit Masking
```
ALU Simulator:
- Operand A: 0b11110000 (240)
- Operand B: 0b00001111 (15)
- Operation: AND
- Result: 0b00000000 (0)
- Use case: Clearing specific bits
```

### Experiment 3: Instruction Timing
```
Control Unit Simulator:
- Compare ADD (1 cycle) vs LD (2 cycles)
- Why does memory access take longer?
- How does this affect performance?
```

---

## 💡 Tips for Educators

1. **Demonstrate live** during lectures
2. Have students **predict results** before clicking "Execute"
3. Use the **binary breakdowns** to teach bit manipulation
4. Show **real Arduino code** alongside simulator operations
5. Create **homework assignments** using these tools

Example Assignment:
> "Use the ALU simulator to find all possible 8-bit values that, when added to themselves, produce a zero result with the Z flag set."

---

## 🚀 Future Enhancements Ideas

Want to contribute? Here are some ideas:
- [ ] Register file visualization showing all 32 registers
- [ ] Pipeline stage visualization (fetch + execute simultaneously)
- [ ] Interrupt handling simulation
- [ ] Memory access timing diagrams
- [ ] Full program execution step-through
- [ ] Compare AVR vs ARM vs x86 architectures

---

## 📚 Learn More

- [ATmega328P Official Datasheet](http://ww1.microchip.com/downloads/en/DeviceDoc/Atmel-7810-Automotive-Microcontrollers-ATmega328P_Datasheet.pdf)
- [AVR Instruction Set Manual](https://ww1.microchip.com/downloads/en/DeviceDoc/AVR-InstructionSet-Manual-DS40002198.pdf)
- [Arduino UNO Hardware](https://docs.arduino.cc/hardware/uno-rev3)

---

**Happy Learning! 🎓**

*Remember: The best way to understand hardware is to interact with it!*
