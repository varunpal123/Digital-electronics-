import { useState } from 'react';
import CPUCore from './components/CPUCore';
import MemorySubsystem from './components/MemorySubsystem';
import PeripheralSubsystem from './components/PeripheralSubsystem';
import ClockPower from './components/ClockPower';
import InterruptSystem from './components/InterruptSystem';
import Pinout from './components/Pinout';
import ZoomModal from './components/ZoomModal';

export type ComponentType = 
  | 'cpu-core' 
  | 'flash' 
  | 'sram' 
  | 'eeprom' 
  | 'timer0' 
  | 'timer1' 
  | 'timer2' 
  | 'usart' 
  | 'spi' 
  | 'i2c' 
  | 'adc' 
  | 'watchdog'
  | 'gpio-b'
  | 'gpio-c'
  | 'gpio-d'
  | 'alu'
  | 'register-file'
  | 'interrupt';

export default function App() {
  const [hoveredComponent, setHoveredComponent] = useState<string | null>(null);
  const [zoomedComponent, setZoomedComponent] = useState<ComponentType | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4 md:p-8">
      <div className="mx-auto max-w-[1900px]">
        {/* Title Bar */}
        <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white p-6 rounded-t-xl border-b-4 border-cyan-400 shadow-2xl">
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight">
            ATmega328P Internal Architecture
          </h1>
          <p className="text-lg text-blue-100 mt-2">
            Harvard RISC • 8-bit AVR • 16MHz • Arduino UNO
          </p>
          <p className="text-sm text-cyan-200 mt-3 flex items-center gap-2">
            <span className="inline-block w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></span>
            Interactive: Hover for details • Click to explore
          </p>
        </div>

        {/* Main Architecture Diagram */}
        <div className="border-4 border-slate-700 rounded-b-xl bg-slate-950 p-6 shadow-2xl">
          <div className="overflow-x-auto">
            <div className="min-w-[1750px]">
              <svg width="1750" height="1400" className="mx-auto">
                <defs>
                  {/* Arrow markers */}
                  <marker id="arrowRed" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto" markerUnits="strokeWidth">
                    <path d="M0,0 L0,6 L9,3 z" fill="#F87171" />
                  </marker>
                  <marker id="arrowBlue" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto" markerUnits="strokeWidth">
                    <path d="M0,0 L0,6 L9,3 z" fill="#60A5FA" />
                  </marker>
                  <marker id="arrowGray" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto" markerUnits="strokeWidth">
                    <path d="M0,0 L0,6 L9,3 z" fill="#94A3B8" />
                  </marker>
                  
                  {/* Glow filters for hover effects */}
                  <filter id="glow">
                    <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
                    <feMerge>
                      <feMergeNode in="coloredBlur"/>
                      <feMergeNode in="SourceGraphic"/>
                    </feMerge>
                  </filter>
                </defs>

                <ClockPower />
                
                <MemorySubsystem 
                  onHover={setHoveredComponent}
                  onZoom={setZoomedComponent}
                  hoveredComponent={hoveredComponent}
                />
                
                {/* Program Memory Bus */}
                <g className="pointer-events-none">
                  <line x1="330" y1="280" x2="460" y2="280" stroke="#F87171" strokeWidth="4" markerEnd="url(#arrowRed)"/>
                  <text x="340" y="270" className="text-xs font-bold fill-red-400">Program Bus</text>
                  <text x="360" y="295" className="text-xs font-semibold fill-red-300">16-bit</text>
                </g>

                <CPUCore 
                  onHover={setHoveredComponent}
                  onZoom={setZoomedComponent}
                  hoveredComponent={hoveredComponent}
                />

                {/* I/O Bus */}
                <g className="pointer-events-none">
                  <line x1="840" y1="550" x2="900" y2="550" stroke="#F87171" strokeWidth="3" markerEnd="url(#arrowRed)"/>
                  <text x="845" y="540" className="text-xs font-bold fill-red-400">I/O Bus</text>
                  <text x="855" y="565" className="text-xs fill-red-300">8-bit</text>
                </g>

                <PeripheralSubsystem 
                  onHover={setHoveredComponent}
                  onZoom={setZoomedComponent}
                  hoveredComponent={hoveredComponent}
                />

                <InterruptSystem 
                  onHover={setHoveredComponent}
                  onZoom={setZoomedComponent}
                  hoveredComponent={hoveredComponent}
                />

                <Pinout />

                {/* Legend */}
                <g id="legend">
                  <rect x="460" y="920" width="380" height="100" fill="#1E293B" stroke="#475569" strokeWidth="2" rx="6"/>
                  <text x="470" y="940" className="font-bold text-sm fill-slate-200">COLOR CODING</text>
                  
                  <rect x="470" y="950" width="70" height="18" fill="#1E3A8A" stroke="#3B82F6" strokeWidth="1.5" rx="3"/>
                  <text x="545" y="962" className="text-xs fill-slate-300">CPU Core</text>
                  
                  <rect x="470" y="973" width="70" height="18" fill="#14532D" stroke="#22C55E" strokeWidth="1.5" rx="3"/>
                  <text x="545" y="985" className="text-xs fill-slate-300">Memory</text>
                  
                  <rect x="650" y="950" width="70" height="18" fill="#7C2D12" stroke="#F97316" strokeWidth="1.5" rx="3"/>
                  <text x="725" y="962" className="text-xs fill-slate-300">Peripherals</text>
                  
                  <line x1="650" y1="980" x2="720" y2="980" stroke="#F87171" strokeWidth="3"/>
                  <text x="725" y="985" className="text-xs fill-slate-300">Data Buses</text>
                </g>

                {/* Architecture Info */}
                <g id="arch-info">
                  <rect x="460" y="1040" width="380" height="100" fill="#1E293B" stroke="#3B82F6" strokeWidth="2" rx="6"/>
                  <text x="470" y="1060" className="font-bold text-sm fill-blue-400">HARVARD ARCHITECTURE</text>
                  <text x="470" y="1077" className="text-xs fill-slate-300">• Separate program and data memory spaces</text>
                  <text x="470" y="1090" className="text-xs fill-slate-300">• Flash: 16-bit wide | SRAM: 8-bit wide</text>
                  <text x="470" y="1103" className="text-xs fill-slate-300">• Simultaneous instruction fetch & data access</text>
                  <text x="470" y="1120" className="text-xs font-semibold fill-cyan-400">RISC: 131 instructions • 16 MIPS @ 16MHz</text>
                </g>
              </svg>
            </div>
          </div>

          {/* Hover Tooltip */}
          {hoveredComponent && (
            <div className="fixed bottom-8 left-1/2 transform -translate-x-1/2 bg-slate-800 text-white px-6 py-3 rounded-lg shadow-2xl border border-cyan-500 z-50 max-w-md animate-fadeIn">
              <p className="text-sm font-medium text-cyan-300">{hoveredComponent}</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="mt-6 p-4 bg-slate-800 rounded-lg border border-slate-700 shadow-lg">
          <p className="text-sm text-slate-300 text-center">
            <span className="font-semibold text-cyan-400">Microchip ATmega328P</span> — All specifications from official datasheet (Doc. 7810D–AVR–01/15)
          </p>
        </div>
      </div>

      {/* Zoom Modal */}
      {zoomedComponent && (
        <ZoomModal 
          component={zoomedComponent}
          onClose={() => setZoomedComponent(null)}
        />
      )}
    </div>
  );
}
