import { useState } from 'react';

export default function InteractiveALU() {
  const [operandA, setOperandA] = useState(42);
  const [operandB, setOperandB] = useState(15);
  const [operation, setOperation] = useState('ADD');
  const [result, setResult] = useState(0);
  const [flags, setFlags] = useState({ C: 0, Z: 0, N: 0, V: 0, H: 0 });

  const operations = [
    'ADD', 'SUB', 'AND', 'OR', 'EOR', 'LSL', 'LSR', 'ASR', 'ROL', 'ROR'
  ];

  const executeOperation = () => {
    let res = 0;
    let carry = 0;
    let overflow = 0;
    let halfCarry = 0;

    const a = operandA & 0xFF;
    const b = operandB & 0xFF;

    switch (operation) {
      case 'ADD':
        res = a + b;
        carry = res > 255 ? 1 : 0;
        halfCarry = ((a & 0x0F) + (b & 0x0F)) > 0x0F ? 1 : 0;
        overflow = ((a ^ res) & (b ^ res) & 0x80) ? 1 : 0;
        break;
      case 'SUB':
        res = a - b;
        carry = res < 0 ? 1 : 0;
        overflow = ((a ^ b) & (a ^ res) & 0x80) ? 1 : 0;
        break;
      case 'AND':
        res = a & b;
        break;
      case 'OR':
        res = a | b;
        break;
      case 'EOR':
        res = a ^ b;
        break;
      case 'LSL':
        res = (a << 1) & 0xFF;
        carry = (a & 0x80) ? 1 : 0;
        break;
      case 'LSR':
        carry = a & 0x01;
        res = a >> 1;
        break;
      case 'ASR':
        carry = a & 0x01;
        res = (a >> 1) | (a & 0x80);
        break;
      case 'ROL':
        carry = (a & 0x80) ? 1 : 0;
        res = ((a << 1) | flags.C) & 0xFF;
        break;
      case 'ROR':
        carry = a & 0x01;
        res = (a >> 1) | (flags.C ? 0x80 : 0);
        break;
    }

    res = res & 0xFF;
    const zero = res === 0 ? 1 : 0;
    const negative = (res & 0x80) ? 1 : 0;

    setResult(res);
    setFlags({
      C: carry,
      Z: zero,
      N: negative,
      V: overflow,
      H: halfCarry
    });
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-br from-blue-900 to-blue-800 p-6 rounded-xl border-2 border-blue-500">
        <h3 className="text-2xl font-bold text-blue-300 mb-4">🧮 Interactive ALU Simulator</h3>
        <p className="text-blue-200 mb-4">
          Try different operations and see how the ALU computes results and updates status flags!
        </p>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Input Controls */}
          <div className="space-y-4">
            <div className="bg-slate-950 p-4 rounded-lg border border-blue-500">
              <label className="block text-cyan-300 font-semibold mb-2">Operand A (Rd)</label>
              <input
                type="number"
                min="0"
                max="255"
                value={operandA}
                onChange={(e) => setOperandA(parseInt(e.target.value) || 0)}
                className="w-full bg-slate-800 text-white px-4 py-2 rounded border border-slate-600 focus:border-cyan-400 focus:outline-none"
              />
              <p className="text-xs text-slate-400 mt-1">
                Decimal: {operandA} | Hex: 0x{operandA.toString(16).toUpperCase().padStart(2, '0')} | Binary: {operandA.toString(2).padStart(8, '0')}
              </p>
            </div>

            <div className="bg-slate-950 p-4 rounded-lg border border-blue-500">
              <label className="block text-cyan-300 font-semibold mb-2">Operand B (Rr)</label>
              <input
                type="number"
                min="0"
                max="255"
                value={operandB}
                onChange={(e) => setOperandB(parseInt(e.target.value) || 0)}
                className="w-full bg-slate-800 text-white px-4 py-2 rounded border border-slate-600 focus:border-cyan-400 focus:outline-none"
              />
              <p className="text-xs text-slate-400 mt-1">
                Decimal: {operandB} | Hex: 0x{operandB.toString(16).toUpperCase().padStart(2, '0')} | Binary: {operandB.toString(2).padStart(8, '0')}
              </p>
            </div>

            <div className="bg-slate-950 p-4 rounded-lg border border-blue-500">
              <label className="block text-cyan-300 font-semibold mb-2">Operation</label>
              <select
                value={operation}
                onChange={(e) => setOperation(e.target.value)}
                className="w-full bg-slate-800 text-white px-4 py-2 rounded border border-slate-600 focus:border-cyan-400 focus:outline-none"
              >
                {operations.map(op => (
                  <option key={op} value={op}>{op}</option>
                ))}
              </select>
            </div>

            <button
              onClick={executeOperation}
              className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 text-white font-bold py-3 px-6 rounded-lg hover:from-cyan-600 hover:to-blue-600 transition-all transform hover:scale-105"
            >
              ⚡ Execute Operation
            </button>
          </div>

          {/* Result Display */}
          <div className="space-y-4">
            <div className="bg-gradient-to-br from-green-900 to-green-800 p-6 rounded-lg border-2 border-green-500">
              <h4 className="text-xl font-bold text-green-300 mb-3">Result</h4>
              <div className="bg-slate-950 p-4 rounded-lg font-mono text-2xl text-center text-green-400 border border-green-600">
                {result}
              </div>
              <div className="mt-3 space-y-1 text-sm">
                <p className="text-green-200">Hex: <span className="font-mono text-green-300">0x{result.toString(16).toUpperCase().padStart(2, '0')}</span></p>
                <p className="text-green-200">Binary: <span className="font-mono text-green-300">{result.toString(2).padStart(8, '0')}</span></p>
              </div>
            </div>

            <div className="bg-gradient-to-br from-amber-900 to-amber-800 p-6 rounded-lg border-2 border-amber-500">
              <h4 className="text-xl font-bold text-amber-300 mb-3">Status Flags (SREG)</h4>
              <div className="grid grid-cols-5 gap-2">
                {Object.entries(flags).map(([flag, value]) => (
                  <div key={flag} className={`p-3 rounded text-center font-mono font-bold ${value ? 'bg-red-600 text-white' : 'bg-slate-700 text-slate-400'}`}>
                    <div className="text-xs">{flag}</div>
                    <div className="text-lg">{value}</div>
                  </div>
                ))}
              </div>
              <div className="mt-3 text-xs text-amber-200 space-y-1">
                <p>C = Carry | Z = Zero | N = Negative</p>
                <p>V = Overflow | H = Half Carry</p>
              </div>
            </div>
          </div>
        </div>

        {/* Operation Description */}
        <div className="mt-6 bg-slate-800 p-4 rounded-lg border border-slate-600">
          <h4 className="text-lg font-bold text-cyan-300 mb-2">How {operation} Works:</h4>
          <p className="text-slate-300 text-sm">
            {operation === 'ADD' && 'Adds two 8-bit values. Sets Carry if result > 255, Zero if result = 0, Negative if bit 7 = 1.'}
            {operation === 'SUB' && 'Subtracts B from A. Sets Carry if borrow needed, updates all flags based on result.'}
            {operation === 'AND' && 'Bitwise AND operation. Each bit: 1 AND 1 = 1, otherwise 0.'}
            {operation === 'OR' && 'Bitwise OR operation. Each bit: 0 OR 0 = 0, otherwise 1.'}
            {operation === 'EOR' && 'Bitwise XOR (exclusive OR). Each bit: same = 0, different = 1.'}
            {operation === 'LSL' && 'Logical Shift Left. All bits move left by 1, LSB becomes 0, MSB goes to Carry.'}
            {operation === 'LSR' && 'Logical Shift Right. All bits move right by 1, MSB becomes 0, LSB goes to Carry.'}
            {operation === 'ASR' && 'Arithmetic Shift Right. Preserves sign bit (MSB), LSB goes to Carry.'}
            {operation === 'ROL' && 'Rotate Left through Carry. MSB → Carry → LSB, all bits rotate.'}
            {operation === 'ROR' && 'Rotate Right through Carry. LSB → Carry → MSB, all bits rotate.'}
          </p>
        </div>
      </div>

      {/* Example Instructions */}
      <div className="bg-gradient-to-br from-purple-900 to-purple-800 p-6 rounded-lg border-2 border-purple-500">
        <h3 className="text-xl font-bold text-purple-300 mb-3">💻 AVR Assembly Examples</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-slate-950 p-4 rounded font-mono text-sm text-green-400 border border-purple-500">
            <div className="text-purple-300 mb-2">// Addition</div>
            <div>LDI R16, 42  ; Load 42 into R16</div>
            <div>LDI R17, 15  ; Load 15 into R17</div>
            <div>ADD R16, R17 ; R16 = R16 + R17</div>
            <div className="text-cyan-300 mt-2">; Result: R16 = 57</div>
          </div>
          <div className="bg-slate-950 p-4 rounded font-mono text-sm text-green-400 border border-purple-500">
            <div className="text-purple-300 mb-2">// Bit masking</div>
            <div>LDI R16, 0b11110000</div>
            <div>LDI R17, 0b00111100</div>
            <div>AND R16, R17 ; Mask bits</div>
            <div className="text-cyan-300 mt-2">; Result: 0b00110000</div>
          </div>
        </div>
      </div>
    </div>
  );
}
