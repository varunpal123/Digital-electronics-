import { ComponentType } from '../App';

interface Props {
  onHover: (component: string | null) => void;
  onZoom: (component: ComponentType) => void;
  hoveredComponent: string | null;
}

export default function InterruptSystem({ onHover, onZoom, hoveredComponent }: Props) {
  return (
    <g 
      id="interrupt-system"
      className="cursor-pointer transition-all"
      onMouseEnter={() => onHover('Interrupt System — 26 hardware vectors')}
      onMouseLeave={() => onHover(null)}
      onClick={() => onZoom('interrupt')}
      style={{ 
        filter: hoveredComponent?.includes('Interrupt') ? 'url(#glow)' : 'none',
        opacity: hoveredComponent && !hoveredComponent.includes('Interrupt') ? 0.5 : 1
      }}
    >
      <rect x="50" y="845" width="380" height="235" fill="#422006" stroke="#F59E0B" strokeWidth="3" rx="6"
        className="hover:fill-yellow-950 transition-colors"/>
      <text x="60" y="865" className="font-bold text-base fill-amber-300">INTERRUPT SYSTEM</text>
      
      <text x="60" y="883" className="text-xs fill-amber-400">Global Enable: SREG[I]</text>
      <text x="60" y="896" className="text-xs fill-red-300">Latency: 4 cycles</text>
      
      {/* Vector table */}
      <rect x="65" y="905" width="350" height="115" fill="#1E3A8A" stroke="#3B82F6" strokeWidth="1.5" rx="4"/>
      <text x="75" y="920" className="text-xs font-bold fill-blue-300">Interrupt Vectors (26 total)</text>
      <text x="75" y="935" className="text-xs fill-cyan-400">0x0000 - RESET</text>
      <text x="75" y="947" className="text-xs fill-cyan-400">0x0002 - INT0</text>
      <text x="75" y="959" className="text-xs fill-cyan-400">0x0004 - INT1</text>
      <text x="75" y="971" className="text-xs fill-cyan-400">0x0006 - PCINT0</text>
      <text x="75" y="983" className="text-xs fill-cyan-400">0x000C - WDT</text>
      <text x="75" y="995" className="text-xs fill-cyan-400">0x001C - TIMER0_OVF</text>
      <text x="75" y="1007" className="text-xs fill-cyan-400">0x0024 - USART_RX...</text>
      
      {/* ISR info */}
      <rect x="65" y="1030" width="165" height="40" fill="#14532D" stroke="#22C55E" strokeWidth="1.5" rx="3"/>
      <text x="75" y="1045" className="text-xs font-bold fill-green-300">ISR Entry:</text>
      <text x="75" y="1058" className="text-xs fill-green-400">Save PC → Clear I</text>
      
      <rect x="240" y="1030" width="175" height="40" fill="#14532D" stroke="#22C55E" strokeWidth="1.5" rx="3"/>
      <text x="250" y="1045" className="text-xs font-bold fill-green-300">RETI Exit:</text>
      <text x="250" y="1058" className="text-xs fill-green-400">Restore PC → Set I</text>
    </g>
  );
}
