import { ComponentType } from '../App';

interface Props {
  onHover: (component: string | null) => void;
  onZoom: (component: ComponentType) => void;
  hoveredComponent: string | null;
}

export default function MemorySubsystem({ onHover, onZoom, hoveredComponent }: Props) {
  return (
    <g id="memory-subsystem">
      <text x="50" y="130" className="font-bold text-base fill-green-400">MEMORY</text>
      
      {/* Flash Program Memory */}
      <g 
        className="cursor-pointer transition-all"
        onMouseEnter={() => onHover('Flash Memory — 32KB program storage')}
        onMouseLeave={() => onHover(null)}
        onClick={() => onZoom('flash')}
        style={{ 
          filter: hoveredComponent?.includes('Flash') ? 'url(#glow)' : 'none',
          opacity: hoveredComponent && !hoveredComponent.includes('Flash') ? 0.5 : 1
        }}
      >
        <rect x="50" y="150" width="280" height="260" fill="#14532D" stroke="#22C55E" strokeWidth="3" rx="6"
          className="hover:fill-green-950 transition-colors"/>
        <text x="60" y="170" className="font-bold text-sm fill-green-300">Flash 32KB</text>
        <text x="60" y="183" className="text-xs fill-green-400">16K × 16-bit words</text>
        
        {/* Vector Table */}
        <rect x="65" y="195" width="250" height="50" fill="#422006" stroke="#F59E0B" strokeWidth="1.5" rx="3"/>
        <text x="75" y="210" className="text-xs font-semibold fill-amber-300">Interrupt Vectors</text>
        <text x="75" y="223" className="text-xs fill-amber-400">0x0000 - RESET</text>
        <text x="75" y="235" className="text-xs fill-amber-400">0x0002 - INT0/1...</text>
        
        {/* Application */}
        <rect x="65" y="250" width="250" height="140" fill="#1E3A8A" stroke="#3B82F6" strokeWidth="1.5" rx="3"/>
        <text x="140" y="310" className="text-sm font-semibold fill-blue-300">Application</text>
        <text x="140" y="330" className="text-xs fill-blue-400">0x0034 - 0x7FFF</text>
      </g>
      
      {/* SRAM */}
      <g 
        className="cursor-pointer transition-all"
        onMouseEnter={() => onHover('SRAM — 2KB volatile memory for variables')}
        onMouseLeave={() => onHover(null)}
        onClick={() => onZoom('sram')}
        style={{ 
          filter: hoveredComponent?.includes('SRAM') ? 'url(#glow)' : 'none',
          opacity: hoveredComponent && !hoveredComponent.includes('SRAM') ? 0.5 : 1
        }}
      >
        <rect x="50" y="430" width="280" height="200" fill="#14532D" stroke="#22C55E" strokeWidth="3" rx="6"
          className="hover:fill-green-950 transition-colors"/>
        <text x="60" y="450" className="font-bold text-sm fill-green-300">SRAM 2KB</text>
        <text x="60" y="463" className="text-xs fill-green-400">0x0100 - 0x08FF</text>
        
        {/* Variables */}
        <rect x="65" y="475" width="250" height="45" fill="#1E3A8A" stroke="#3B82F6" strokeWidth="1.5" rx="3"/>
        <text x="150" y="495" className="text-xs font-semibold fill-blue-300">Variables ↑</text>
        <text x="140" y="510" className="text-xs fill-blue-400">from 0x0100</text>
        
        {/* Collision */}
        <rect x="65" y="525" width="250" height="18" fill="#7F1D1D" stroke="#F87171" strokeWidth="1.5" rx="2"/>
        <text x="125" y="537" className="text-xs font-bold fill-red-300">⚠ Collision Zone</text>
        
        {/* Stack */}
        <rect x="65" y="548" width="250" height="45" fill="#581C87" stroke="#A78BFA" strokeWidth="1.5" rx="3"/>
        <text x="155" y="568" className="text-xs font-semibold fill-purple-300">Stack ↓</text>
        <text x="135" y="583" className="text-xs fill-purple-400">from 0x08FF</text>
      </g>
      
      {/* EEPROM */}
      <g 
        className="cursor-pointer transition-all"
        onMouseEnter={() => onHover('EEPROM — 1KB non-volatile storage')}
        onMouseLeave={() => onHover(null)}
        onClick={() => onZoom('eeprom')}
        style={{ 
          filter: hoveredComponent?.includes('EEPROM') ? 'url(#glow)' : 'none',
          opacity: hoveredComponent && !hoveredComponent.includes('EEPROM') ? 0.5 : 1
        }}
      >
        <rect x="50" y="650" width="280" height="85" fill="#14532D" stroke="#22C55E" strokeWidth="3" rx="6"
          className="hover:fill-green-950 transition-colors"/>
        <text x="60" y="670" className="font-bold text-sm fill-green-300">EEPROM 1KB</text>
        <text x="60" y="683" className="text-xs fill-green-400">0x000 - 0x3FF</text>
        <text x="60" y="698" className="text-xs fill-green-400">Non-volatile</text>
        <text x="60" y="710" className="text-xs fill-green-400">100K cycles</text>
        <text x="60" y="722" className="text-xs fill-green-400">3.4ms write</text>
      </g>
      
      {/* I/O Space */}
      <rect x="50" y="755" width="280" height="70" fill="#422006" stroke="#F59E0B" strokeWidth="3" rx="6"/>
      <text x="60" y="775" className="font-bold text-sm fill-amber-300">I/O Registers</text>
      <text x="60" y="788" className="text-xs fill-amber-400">0x20 - 0xFF</text>
      <text x="60" y="803" className="text-xs fill-amber-400">Memory-mapped</text>
      <text x="60" y="815" className="text-xs fill-amber-400">peripherals</text>
    </g>
  );
}
