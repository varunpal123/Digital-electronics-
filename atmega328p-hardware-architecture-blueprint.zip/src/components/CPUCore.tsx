import { ComponentType } from '../App';

interface Props {
  onHover: (component: string | null) => void;
  onZoom: (component: ComponentType) => void;
  hoveredComponent: string | null;
}

export default function CPUCore({ onHover, onZoom, hoveredComponent }: Props) {
  return (
    <g id="cpu-core">
      <rect x="460" y="150" width="380" height="675" fill="#1E3A8A" stroke="#3B82F6" strokeWidth="4" rx="8"/>
      <text x="580" y="175" className="font-bold text-lg fill-blue-300">AVR CPU CORE</text>
      
      {/* Pipeline */}
      <rect x="650" y="185" width="170" height="35" fill="#422006" stroke="#F59E0B" strokeWidth="1.5" rx="4"/>
      <text x="660" y="200" className="text-xs font-bold fill-amber-300">2-Stage Pipeline</text>
      <rect x="660" y="206" width="70" height="10" fill="#1E3A8A" stroke="#3B82F6" strokeWidth="1"/>
      <text x="665" y="214" className="text-xs fill-blue-300">Fetch</text>
      <rect x="730" y="206" width="70" height="10" fill="#14532D" stroke="#22C55E" strokeWidth="1"/>
      <text x="735" y="214" className="text-xs fill-green-300">Exec</text>
      
      {/* Program Counter */}
      <g 
        className="cursor-pointer transition-all"
        onMouseEnter={() => onHover('Program Counter — Points to next instruction')}
        onMouseLeave={() => onHover(null)}
        onClick={() => onZoom('cpu-core')}
        style={{ filter: hoveredComponent?.includes('Program') ? 'url(#glow)' : 'none' }}
      >
        <rect x="480" y="235" width="340" height="38" fill="#0C4A6E" stroke="#38BDF8" strokeWidth="2" rx="4"
          className="hover:fill-sky-950 transition-colors"/>
        <text x="490" y="252" className="text-sm font-bold fill-cyan-300">Program Counter</text>
        <text x="490" y="265" className="text-xs fill-cyan-400">PC [15:0] — 16-bit</text>
      </g>
      
      {/* Instruction Fetch */}
      <g 
        className="cursor-pointer transition-all"
        onMouseEnter={() => onHover('Instruction Fetch — Retrieves instructions from Flash')}
        onMouseLeave={() => onHover(null)}
        onClick={() => onZoom('cpu-core')}
        style={{ filter: hoveredComponent?.includes('Instruction Fetch') ? 'url(#glow)' : 'none' }}
      >
        <rect x="480" y="280" width="340" height="38" fill="#0C4A6E" stroke="#38BDF8" strokeWidth="2" rx="4"
          className="hover:fill-sky-950 transition-colors"/>
        <text x="490" y="297" className="text-sm font-bold fill-cyan-300">Instruction Fetch</text>
        <text x="490" y="310" className="text-xs fill-cyan-400">16-bit from Flash</text>
      </g>
      
      {/* Decoder */}
      <g 
        className="cursor-pointer transition-all"
        onMouseEnter={() => onHover('Instruction Decoder — Decodes 16-bit opcodes')}
        onMouseLeave={() => onHover(null)}
        onClick={() => onZoom('cpu-core')}
        style={{ filter: hoveredComponent?.includes('Decoder') ? 'url(#glow)' : 'none' }}
      >
        <rect x="480" y="325" width="340" height="38" fill="#0C4A6E" stroke="#38BDF8" strokeWidth="2" rx="4"
          className="hover:fill-sky-950 transition-colors"/>
        <text x="490" y="342" className="text-sm font-bold fill-cyan-300">Instruction Decoder</text>
        <text x="490" y="355" className="text-xs fill-cyan-400">Hardwired logic</text>
      </g>
      
      {/* Control Unit */}
      <g 
        className="cursor-pointer transition-all"
        onMouseEnter={() => onHover('Control Unit — Orchestrates all CPU operations')}
        onMouseLeave={() => onHover(null)}
        onClick={() => onZoom('cpu-core')}
        style={{ filter: hoveredComponent?.includes('Control Unit') ? 'url(#glow)' : 'none' }}
      >
        <rect x="480" y="370" width="340" height="42" fill="#0C4A6E" stroke="#38BDF8" strokeWidth="2" rx="4"
          className="hover:fill-sky-950 transition-colors"/>
        <text x="490" y="387" className="text-sm font-bold fill-cyan-300">Control Unit</text>
        <text x="490" y="400" className="text-xs fill-cyan-400">FSM — Control signals</text>
      </g>
      
      {/* Control line */}
      <line x1="650" y1="412" x2="650" y2="428" stroke="#94A3B8" strokeWidth="2" strokeDasharray="3,3" markerEnd="url(#arrowGray)"/>
      
      {/* Register File */}
      <g 
        className="cursor-pointer transition-all"
        onMouseEnter={() => onHover('Register File — 32 × 8-bit GPR (R0-R31)')}
        onMouseLeave={() => onHover(null)}
        onClick={() => onZoom('register-file')}
        style={{ filter: hoveredComponent?.includes('Register') ? 'url(#glow)' : 'none' }}
      >
        <rect x="480" y="428" width="340" height="95" fill="#0C4A6E" stroke="#38BDF8" strokeWidth="2" rx="4"
          className="hover:fill-sky-950 transition-colors"/>
        <text x="490" y="445" className="text-sm font-bold fill-cyan-300">Register File</text>
        <text x="490" y="458" className="text-xs fill-cyan-400">32 × 8-bit (R0-R31)</text>
        <text x="490" y="473" className="text-xs fill-green-300">X=R27:26 Y=R29:28 Z=R31:30</text>
        <text x="490" y="486" className="text-xs fill-purple-300">Dual read • Single write</text>
        <text x="490" y="498" className="text-xs fill-amber-300">16-bit pointers</text>
      </g>
      
      {/* Data paths */}
      <line x1="580" y1="523" x2="580" y2="548" stroke="#F87171" strokeWidth="3" markerEnd="url(#arrowRed)"/>
      <text x="555" y="538" className="text-xs fill-red-400">Rd</text>
      
      <line x1="720" y1="523" x2="720" y2="548" stroke="#F87171" strokeWidth="3" markerEnd="url(#arrowRed)"/>
      <text x="695" y="538" className="text-xs fill-red-400">Rr/K</text>
      
      {/* ALU */}
      <g 
        className="cursor-pointer transition-all"
        onMouseEnter={() => onHover('ALU — Arithmetic & Logic operations')}
        onMouseLeave={() => onHover(null)}
        onClick={() => onZoom('alu')}
        style={{ filter: hoveredComponent?.includes('ALU') ? 'url(#glow)' : 'none' }}
      >
        <rect x="480" y="548" width="340" height="70" fill="#0C4A6E" stroke="#38BDF8" strokeWidth="2" rx="4"
          className="hover:fill-sky-950 transition-colors"/>
        <text x="490" y="565" className="text-sm font-bold fill-cyan-300">ALU</text>
        <text x="490" y="578" className="text-xs fill-cyan-400">ADD SUB AND OR XOR</text>
        <text x="490" y="591" className="text-xs fill-cyan-400">LSL LSR ASR ROL ROR</text>
        <text x="490" y="604" className="text-xs fill-green-300">8-bit operations</text>
      </g>
      
      {/* ALU output */}
      <line x1="650" y1="618" x2="650" y2="643" stroke="#F87171" strokeWidth="3" markerEnd="url(#arrowRed)"/>
      <text x="625" y="633" className="text-xs fill-red-400">Result</text>
      
      <line x1="730" y1="618" x2="730" y2="643" stroke="#F87171" strokeWidth="2" markerEnd="url(#arrowRed)"/>
      <text x="710" y="633" className="text-xs fill-red-400">Flags</text>
      
      {/* SREG */}
      <rect x="480" y="643" width="340" height="155" fill="#422006" stroke="#F59E0B" strokeWidth="3" rx="4"/>
      <text x="490" y="660" className="text-sm font-bold fill-amber-300">SREG — Status Register</text>
      
      {/* Flags */}
      <g className="font-mono">
        {['I', 'T', 'H', 'S', 'V', 'N', 'Z', 'C'].map((flag, i) => (
          <g key={flag}>
            <rect x={490 + i * 40} y="670" width="35" height="30" fill="#1E3A8A" stroke="#3B82F6" strokeWidth="1.5" rx="2"/>
            <text x={497 + i * 40} y="682" className="text-xs fill-blue-300">B{7-i}</text>
            <text x={502 + i * 40} y="694" className="text-sm font-bold fill-cyan-300">{flag}</text>
          </g>
        ))}
      </g>
      
      {/* Flag descriptions */}
      <text x="490" y="715" className="text-xs fill-slate-400">I=Int T=Bit H=Half S=Sign</text>
      <text x="490" y="728" className="text-xs fill-slate-400">V=Ovf N=Neg Z=Zero C=Carry</text>
      
      {/* Feedback */}
      <path d="M 430 700 Q 400 550 430 390" stroke="#F87171" strokeWidth="2" fill="none" markerEnd="url(#arrowRed)" strokeDasharray="4,2"/>
      <text x="365" y="545" className="text-xs fill-red-400" transform="rotate(-90 365 545)">Conditional</text>
      
      {/* Data bus */}
      <line x1="480" y1="480" x2="400" y2="480" stroke="#F87171" strokeWidth="3"/>
      <line x1="400" y1="480" x2="400" y2="790" stroke="#F87171" strokeWidth="3"/>
      <line x1="330" y1="790" x2="400" y2="790" stroke="#F87171" strokeWidth="3" markerEnd="url(#arrowRed)"/>
      <text x="345" y="780" className="text-xs font-bold fill-red-400">Data 8-bit</text>
    </g>
  );
}
