import { useState } from 'react';

export default function InteractiveDecoder() {
  const [instruction, setInstruction] = useState('0xE000');
  const [decoded, setDecoded] = useState<any>(null);

  const instructionSet = [
    { opcode: '0xE000', binary: '1110 0000 0000 0000', asm: 'LDI R16, 0', type: 'Load Immediate', format: 'LDI Rd, K' },
    { opcode: '0x0F01', binary: '0000 1111 0000 0001', asm: 'ADD R16, R17', type: 'Addition', format: 'ADD Rd, Rr' },
    { opcode: '0x9508', binary: '1001 0101 0000 1000', asm: 'RET', type: 'Return', format: 'RET' },
    { opcode: '0x940C', binary: '1001 0100 0000 1100', asm: 'JMP addr', type: 'Jump', format: 'JMP k' },
    { opcode: '0x2711', binary: '0010 0111 0001 0001', asm: 'AND R17, R17', type: 'Logical AND', format: 'AND Rd, Rr' },
  ];

  const decodeInstruction = () => {
    const value = parseInt(instruction.replace('0x', ''), 16);
    const binary = value.toString(2).padStart(16, '0');
    
    // Simplified decoder logic
    let result: any = {
      raw: instruction,
      binary: binary.match(/.{1,4}/g)?.join(' '),
      hex: '0x' + value.toString(16).toUpperCase().padStart(4, '0')
    };

    // Detect instruction type based on opcode pattern
    // const opBits = binary.substring(0, 4);
    
    if (binary.substring(0, 4) === '1110') {
      // LDI - Load Immediate
      const rd = parseInt(binary.substring(4, 8), 2) + 16;
      const k = parseInt(binary.substring(8, 12) + binary.substring(12, 16), 2);
      result = {
        ...result,
        type: 'Load Immediate (LDI)',
        format: 'LDI Rd, K',
        asm: `LDI R${rd}, ${k}`,
        description: `Load constant ${k} into register R${rd}`,
        operands: { Rd: `R${rd}`, K: k },
        cycles: 1,
        fields: [
          { name: 'Opcode', bits: '1110', desc: 'LDI instruction' },
          { name: 'K[7:4]', bits: binary.substring(4, 8), value: k >> 4 },
          { name: 'd[3:0]', bits: binary.substring(8, 12), value: rd - 16 },
          { name: 'K[3:0]', bits: binary.substring(12, 16), value: k & 0x0F }
        ]
      };
    } else if (binary.substring(0, 6) === '000011') {
      // ADD
      const rd = parseInt(binary.substring(9, 14), 2);
      const rr = parseInt(binary.substring(14, 16) + binary.substring(6, 9), 2);
      result = {
        ...result,
        type: 'Addition (ADD)',
        format: 'ADD Rd, Rr',
        asm: `ADD R${rd}, R${rr}`,
        description: `Add R${rr} to R${rd}, store result in R${rd}`,
        operands: { Rd: `R${rd}`, Rr: `R${rr}` },
        cycles: 1,
        fields: [
          { name: 'Opcode', bits: '000011', desc: 'ADD instruction' },
          { name: 'd[4:0]', bits: binary.substring(9, 14), value: rd },
          { name: 'r[4:0]', bits: binary.substring(14, 16) + binary.substring(6, 9), value: rr }
        ]
      };
    } else if (binary === '1001010100001000') {
      // RET
      result = {
        ...result,
        type: 'Return (RET)',
        format: 'RET',
        asm: 'RET',
        description: 'Return from subroutine',
        operands: {},
        cycles: 4,
        fields: [
          { name: 'Opcode', bits: '1001010100001000', desc: 'RET instruction' }
        ]
      };
    } else {
      result = {
        ...result,
        type: 'Unknown',
        format: '???',
        asm: 'Unknown instruction',
        description: 'This opcode is not recognized',
        operands: {},
        cycles: 0,
        fields: []
      };
    }

    setDecoded(result);
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-br from-purple-900 to-purple-800 p-6 rounded-xl border-2 border-purple-500">
        <h3 className="text-2xl font-bold text-purple-300 mb-4">🔍 Instruction Decoder Simulator</h3>
        <p className="text-purple-200 mb-4">
          Enter any 16-bit instruction and watch how the decoder breaks it down into its components!
        </p>

        {/* Input Section */}
        <div className="grid md:grid-cols-2 gap-6 mb-6">
          <div className="space-y-4">
            <div className="bg-slate-950 p-4 rounded-lg border-2 border-purple-500">
              <label className="block text-purple-300 font-semibold mb-2">16-bit Instruction (Hex)</label>
              <input
                type="text"
                value={instruction}
                onChange={(e) => setInstruction(e.target.value)}
                placeholder="0xE000"
                className="w-full bg-slate-800 text-white px-4 py-2 rounded border border-slate-600 focus:border-purple-400 focus:outline-none font-mono text-lg"
              />
            </div>

            <button
              onClick={decodeInstruction}
              className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold py-3 px-6 rounded-lg hover:from-purple-600 hover:to-pink-600 transition-all transform hover:scale-105"
            >
              🔍 Decode Instruction
            </button>

            {/* Quick Examples */}
            <div className="bg-slate-800 p-4 rounded-lg border border-purple-500">
              <h5 className="text-sm font-bold text-purple-300 mb-2">Quick Examples:</h5>
              <div className="space-y-1">
                {instructionSet.map((inst, idx) => (
                  <button
                    key={idx}
                    onClick={() => setInstruction(inst.opcode)}
                    className="block w-full text-left px-3 py-2 bg-slate-700 hover:bg-slate-600 rounded text-xs font-mono text-slate-300 transition-colors"
                  >
                    {inst.opcode} - {inst.asm}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Decoded Output */}
          {decoded && (
            <div className="space-y-4">
              <div className="bg-gradient-to-br from-cyan-900 to-cyan-800 p-5 rounded-lg border-2 border-cyan-500">
                <h4 className="text-lg font-bold text-cyan-300 mb-3">Decoded Instruction</h4>
                <div className="space-y-3">
                  <div className="bg-slate-950 p-3 rounded">
                    <div className="text-xs text-cyan-400 mb-1">Assembly:</div>
                    <div className="font-mono text-xl text-white font-bold">{decoded.asm}</div>
                  </div>
                  <div className="bg-slate-950 p-3 rounded">
                    <div className="text-xs text-cyan-400 mb-1">Type:</div>
                    <div className="text-cyan-300">{decoded.type}</div>
                  </div>
                  <div className="bg-slate-950 p-3 rounded">
                    <div className="text-xs text-cyan-400 mb-1">Description:</div>
                    <div className="text-sm text-slate-300">{decoded.description}</div>
                  </div>
                  <div className="bg-slate-950 p-3 rounded">
                    <div className="text-xs text-cyan-400 mb-1">Execution Time:</div>
                    <div className="text-green-300 font-bold">{decoded.cycles} clock cycle{decoded.cycles !== 1 ? 's' : ''}</div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Binary Breakdown */}
        {decoded && decoded.binary && (
          <div className="bg-slate-950 p-6 rounded-lg border-2 border-purple-500">
            <h4 className="text-lg font-bold text-purple-300 mb-4">Binary Field Breakdown</h4>
            
            {/* Binary Display */}
            <div className="mb-6 p-4 bg-slate-900 rounded border border-purple-600">
              <div className="text-center">
                <div className="text-xs text-purple-300 mb-2">16-bit Instruction Word</div>
                <div className="font-mono text-2xl text-green-400 tracking-wider">{decoded.binary}</div>
                <div className="font-mono text-lg text-slate-500 mt-1">{decoded.hex}</div>
              </div>
            </div>

            {/* Field Explanation */}
            {decoded.fields && decoded.fields.length > 0 && (
              <div className="space-y-3">
                {decoded.fields.map((field: any, idx: number) => (
                  <div key={idx} className="bg-slate-900 p-4 rounded border border-purple-700">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-purple-300 font-bold">{field.name}</span>
                      <span className="font-mono text-green-400">{field.bits}</span>
                    </div>
                    <div className="text-sm text-slate-400">{field.desc}</div>
                    {field.value !== undefined && (
                      <div className="text-xs text-cyan-300 mt-1">Value: {field.value}</div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Operands */}
        {decoded && decoded.operands && Object.keys(decoded.operands).length > 0 && (
          <div className="mt-6 bg-gradient-to-br from-green-900 to-green-800 p-6 rounded-lg border-2 border-green-500">
            <h4 className="text-lg font-bold text-green-300 mb-3">Operands</h4>
            <div className="grid grid-cols-2 gap-4">
              {Object.entries(decoded.operands).map(([key, value]: [string, any]) => (
                <div key={key} className="bg-slate-950 p-4 rounded border border-green-600">
                  <div className="text-green-400 text-xs mb-1">{key}</div>
                  <div className="text-white font-mono text-xl">{value}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* How Decoder Works */}
      <div className="bg-gradient-to-br from-amber-900 to-amber-800 p-6 rounded-lg border-2 border-amber-500">
        <h3 className="text-xl font-bold text-amber-300 mb-4">🛠️ How the Decoder Works</h3>
        <div className="space-y-4 text-amber-100">
          <div className="bg-slate-950 p-4 rounded border border-amber-500">
            <h5 className="font-bold text-amber-300 mb-2">1. Pattern Matching</h5>
            <p className="text-sm">The decoder examines the opcode bits (usually the first 4-6 bits) to identify the instruction type. Each instruction has a unique bit pattern.</p>
          </div>
          <div className="bg-slate-950 p-4 rounded border border-amber-500">
            <h5 className="font-bold text-amber-300 mb-2">2. Field Extraction</h5>
            <p className="text-sm">Once the instruction type is known, specific bit fields are extracted: register addresses (Rd, Rr), constants (K), or addresses.</p>
          </div>
          <div className="bg-slate-950 p-4 rounded border border-amber-500">
            <h5 className="font-bold text-amber-300 mb-2">3. Control Signal Generation</h5>
            <p className="text-sm">The decoder generates control signals for the ALU, register file, and memory. These signals tell each component what to do during execution.</p>
          </div>
          <div className="bg-slate-950 p-4 rounded border border-amber-500">
            <h5 className="font-bold text-amber-300 mb-2">4. Hardwired Logic</h5>
            <p className="text-sm">The ATmega328P uses hardwired control (not microcode), meaning the decoder is implemented as combinational logic circuits for maximum speed - 1 cycle decode!</p>
          </div>
        </div>
      </div>

      {/* Instruction Format Reference */}
      <div className="bg-gradient-to-br from-blue-900 to-blue-800 p-6 rounded-lg border-2 border-blue-500">
        <h3 className="text-xl font-bold text-blue-300 mb-4">📖 Common Instruction Formats</h3>
        <div className="grid md:grid-cols-2 gap-4 text-sm font-mono">
          <div className="bg-slate-950 p-4 rounded border border-blue-500">
            <div className="text-blue-300 font-bold mb-2">Register-Register</div>
            <div className="text-green-400">ADD Rd, Rr</div>
            <div className="text-slate-400 text-xs mt-1">Both operands from registers</div>
          </div>
          <div className="bg-slate-950 p-4 rounded border border-blue-500">
            <div className="text-blue-300 font-bold mb-2">Register-Immediate</div>
            <div className="text-green-400">LDI Rd, K</div>
            <div className="text-slate-400 text-xs mt-1">One register, one constant</div>
          </div>
          <div className="bg-slate-950 p-4 rounded border border-blue-500">
            <div className="text-blue-300 font-bold mb-2">Branch</div>
            <div className="text-green-400">BRNE label</div>
            <div className="text-slate-400 text-xs mt-1">Conditional program flow</div>
          </div>
          <div className="bg-slate-950 p-4 rounded border border-blue-500">
            <div className="text-blue-300 font-bold mb-2">Jump/Call</div>
            <div className="text-green-400">JMP address</div>
            <div className="text-slate-400 text-xs mt-1">Absolute address jump</div>
          </div>
        </div>
      </div>
    </div>
  );
}
