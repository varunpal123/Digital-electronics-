export default function Pinout() {
  return (
    <g id="pinout">
      <rect x="1230" y="150" width="250" height="930" fill="#1E293B" stroke="#475569" strokeWidth="3" rx="6"/>
      <text x="1300" y="175" className="font-bold text-sm fill-slate-300">28-Pin DIP</text>
      <text x="1275" y="190" className="text-xs fill-slate-400">ATmega328P-PU</text>
      
      {/* Left pins */}
      <g className="text-xs font-mono">
        <circle cx="1250" cy="210" r="3" fill="#94A3B8"/>
        <text x="1260" y="213" fill="#94A3B8">1 - PC6/RESET</text>
        
        <circle cx="1250" cy="230" r="3" fill="#94A3B8"/>
        <text x="1260" y="233" fill="#94A3B8">2 - PD0 RX</text>
        
        <circle cx="1250" cy="250" r="3" fill="#94A3B8"/>
        <text x="1260" y="253" fill="#94A3B8">3 - PD1 TX</text>
        
        <circle cx="1250" cy="270" r="3" fill="#94A3B8"/>
        <text x="1260" y="273" fill="#94A3B8">4 - PD2 INT0</text>
        
        <circle cx="1250" cy="290" r="3" fill="#94A3B8"/>
        <text x="1260" y="293" fill="#94A3B8">5 - PD3 INT1</text>
        
        <circle cx="1250" cy="310" r="3" fill="#94A3B8"/>
        <text x="1260" y="313" fill="#94A3B8">6 - PD4</text>
        
        <circle cx="1250" cy="330" r="3" fill="#94A3B8"/>
        <text x="1260" y="333" fill="#94A3B8">7 - VCC</text>
        
        <circle cx="1250" cy="350" r="3" fill="#94A3B8"/>
        <text x="1260" y="353" fill="#94A3B8">8 - GND</text>
        
        <circle cx="1250" cy="370" r="3" fill="#94A3B8"/>
        <text x="1260" y="373" fill="#94A3B8">9 - XTAL1</text>
        
        <circle cx="1250" cy="390" r="3" fill="#94A3B8"/>
        <text x="1260" y="393" fill="#94A3B8">10 - XTAL2</text>
        
        <circle cx="1250" cy="410" r="3" fill="#94A3B8"/>
        <text x="1260" y="413" fill="#94A3B8">11 - PD5</text>
        
        <circle cx="1250" cy="430" r="3" fill="#94A3B8"/>
        <text x="1260" y="433" fill="#94A3B8">12 - PD6</text>
        
        <circle cx="1250" cy="450" r="3" fill="#94A3B8"/>
        <text x="1260" y="453" fill="#94A3B8">13 - PD7</text>
        
        <circle cx="1250" cy="470" r="3" fill="#94A3B8"/>
        <text x="1260" y="473" fill="#94A3B8">14 - PB0</text>
      </g>
      
      {/* Right pins */}
      <g className="text-xs font-mono">
        <text x="1365" y="473" fill="#94A3B8" textAnchor="end">PB1 - 15</text>
        <circle cx="1470" cy="470" r="3" fill="#94A3B8"/>
        
        <text x="1365" y="453" fill="#94A3B8" textAnchor="end">PB2 SS - 16</text>
        <circle cx="1470" cy="450" r="3" fill="#94A3B8"/>
        
        <text x="1365" y="433" fill="#94A3B8" textAnchor="end">PB3 MOSI - 17</text>
        <circle cx="1470" cy="430" r="3" fill="#94A3B8"/>
        
        <text x="1365" y="413" fill="#94A3B8" textAnchor="end">PB4 MISO - 18</text>
        <circle cx="1470" cy="410" r="3" fill="#94A3B8"/>
        
        <text x="1365" y="393" fill="#94A3B8" textAnchor="end">PB5 SCK - 19</text>
        <circle cx="1470" cy="390" r="3" fill="#94A3B8"/>
        
        <text x="1365" y="373" fill="#94A3B8" textAnchor="end">AVCC - 20</text>
        <circle cx="1470" cy="370" r="3" fill="#94A3B8"/>
        
        <text x="1365" y="353" fill="#94A3B8" textAnchor="end">AREF - 21</text>
        <circle cx="1470" cy="350" r="3" fill="#94A3B8"/>
        
        <text x="1365" y="333" fill="#94A3B8" textAnchor="end">GND - 22</text>
        <circle cx="1470" cy="330" r="3" fill="#94A3B8"/>
        
        <text x="1365" y="313" fill="#94A3B8" textAnchor="end">PC0 ADC0 - 23</text>
        <circle cx="1470" cy="310" r="3" fill="#94A3B8"/>
        
        <text x="1365" y="293" fill="#94A3B8" textAnchor="end">PC1 ADC1 - 24</text>
        <circle cx="1470" cy="290" r="3" fill="#94A3B8"/>
        
        <text x="1365" y="273" fill="#94A3B8" textAnchor="end">PC2 ADC2 - 25</text>
        <circle cx="1470" cy="270" r="3" fill="#94A3B8"/>
        
        <text x="1365" y="253" fill="#94A3B8" textAnchor="end">PC3 ADC3 - 26</text>
        <circle cx="1470" cy="250" r="3" fill="#94A3B8"/>
        
        <text x="1365" y="233" fill="#94A3B8" textAnchor="end">PC4 SDA - 27</text>
        <circle cx="1470" cy="230" r="3" fill="#94A3B8"/>
        
        <text x="1365" y="213" fill="#94A3B8" textAnchor="end">PC5 SCL - 28</text>
        <circle cx="1470" cy="210" r="3" fill="#94A3B8"/>
      </g>
      
      {/* Notch */}
      <path d="M 1330 205 Q 1360 185 1390 205" stroke="#475569" strokeWidth="2" fill="none"/>
      
      {/* Arduino mapping */}
      <rect x="1240" y="495" width="230" height="95" fill="#1E3A8A" stroke="#3B82F6" strokeWidth="1.5" rx="4"/>
      <text x="1250" y="510" className="text-xs font-bold fill-blue-300">Arduino Mapping:</text>
      <text x="1250" y="525" className="text-xs fill-cyan-400">D0-D7 = PD0-PD7</text>
      <text x="1250" y="538" className="text-xs fill-cyan-400">D8-D13 = PB0-PB5</text>
      <text x="1250" y="551" className="text-xs fill-cyan-400">A0-A5 = PC0-PC5</text>
      <text x="1250" y="567" className="text-xs fill-green-300">LED: D13 = PB5</text>
      <text x="1250" y="580" className="text-xs fill-amber-300">I2C: A4/A5</text>
      
      {/* Specs */}
      <rect x="1240" y="600" width="230" height="125" fill="#14532D" stroke="#22C55E" strokeWidth="1.5" rx="4"/>
      <text x="1250" y="615" className="text-xs font-bold fill-green-300">Specifications:</text>
      <text x="1250" y="630" className="text-xs fill-green-400">• 8-bit AVR RISC</text>
      <text x="1250" y="643" className="text-xs fill-green-400">• 16 MHz max</text>
      <text x="1250" y="656" className="text-xs fill-green-400">• 32KB Flash</text>
      <text x="1250" y="669" className="text-xs fill-green-400">• 2KB SRAM</text>
      <text x="1250" y="682" className="text-xs fill-green-400">• 1KB EEPROM</text>
      <text x="1250" y="695" className="text-xs fill-green-400">• 23 I/O pins</text>
      <text x="1250" y="708" className="text-xs fill-green-400">• 131 instructions</text>
      <text x="1250" y="718" className="text-xs fill-cyan-300">16 MIPS @ 16MHz</text>
      
      {/* Power */}
      <rect x="1240" y="735" width="230" height="75" fill="#422006" stroke="#F59E0B" strokeWidth="1.5" rx="4"/>
      <text x="1250" y="750" className="text-xs font-bold fill-amber-300">Power:</text>
      <text x="1250" y="765" className="text-xs fill-amber-400">Active: ~5mA</text>
      <text x="1250" y="778" className="text-xs fill-amber-400">Sleep: ~0.1µA</text>
      <text x="1250" y="791" className="text-xs fill-amber-400">Voltage: 1.8-5.5V</text>
      <text x="1250" y="803" className="text-xs fill-amber-400">Temp: -40 to +85°C</text>
      
      {/* Datasheet */}
      <rect x="1240" y="820" width="230" height="70" fill="#1E293B" stroke="#475569" strokeWidth="1.5" rx="4"/>
      <text x="1250" y="835" className="text-xs font-bold fill-slate-300">Datasheet:</text>
      <text x="1250" y="850" className="text-xs fill-slate-400">Microchip ATmega328P</text>
      <text x="1250" y="863" className="text-xs fill-slate-400">Doc. 7810D-AVR-01/15</text>
      <text x="1250" y="878" className="text-xs fill-cyan-400">Die: ~9mm² 0.35µm</text>
      
      {/* Manufacturer */}
      <rect x="1240" y="900" width="230" height="50" fill="#581C87" stroke="#A78BFA" strokeWidth="1.5" rx="4"/>
      <text x="1250" y="915" className="text-xs font-bold fill-purple-300">Manufacturer:</text>
      <text x="1250" y="930" className="text-xs fill-purple-400">Microchip</text>
      <text x="1250" y="943" className="text-xs fill-purple-400">(formerly Atmel)</text>
    </g>
  );
}
