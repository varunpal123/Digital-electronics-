import { useState } from 'react';

export default function InteractiveControlUnit() {
  const [selectedInstruction, setSelectedInstruction] = useState('ADD');
  const [controlSignals, setControlSignals] = useState<any>(null);

  const instructions = [
    { name: 'ADD', desc: 'Add two registers', full: 'ADD R16, R17' },
    { name: 'SUB', desc: 'Subtract registers', full: 'SUB R16, R17' },
    { name: 'LDI', desc: 'Load immediate', full: 'LDI R16, 42' },
    { name: 'MOV', desc: 'Move between registers', full: 'MOV R16, R17' },
    { name: 'ST', desc: 'Store to memory', full: 'ST X, R16' },
    { name: 'LD', desc: 'Load from memory', full: 'LD R16, X' },
  ];

  const generateControlSignals = () => {
    let signals: any = {};

    switch (selectedInstruction) {
      case 'ADD':
        signals = {
          'Register File': { 'Read Port A': 'R16', 'Read Port B': 'R17', 'Write Enable': 'YES', 'Write Port': 'R16' },
          'ALU': { 'Operation': 'ADD', 'Operand A Source': 'Rd', 'Operand B Source': 'Rr' },
          'SREG': { 'Update Flags': 'C Z N V H S' },
          'Program Counter': { 'Action': 'PC = PC + 1' },
          'Memory': { 'Read': 'NO', 'Write': 'NO' },
          'Timing': { 'Cycles': '1', 'Pipeline': 'Execute while fetching next' }
        };
        break;
      case 'SUB':
        signals = {
          'Register File': { 'Read Port A': 'R16', 'Read Port B': 'R17', 'Write Enable': 'YES', 'Write Port': 'R16' },
          'ALU': { 'Operation': 'SUB', 'Operand A Source': 'Rd', 'Operand B Source': 'Rr' },
          'SREG': { 'Update Flags': 'C Z N V H S' },
          'Program Counter': { 'Action': 'PC = PC + 1' },
          'Memory': { 'Read': 'NO', 'Write': 'NO' },
          'Timing': { 'Cycles': '1', 'Pipeline': 'Execute while fetching next' }
        };
        break;
      case 'LDI':
        signals = {
          'Register File': { 'Read Port A': 'NONE', 'Read Port B': 'NONE', 'Write Enable': 'YES', 'Write Port': 'R16' },
          'ALU': { 'Operation': 'PASS', 'Operand A Source': 'Immediate (42)', 'Operand B Source': 'NONE' },
          'SREG': { 'Update Flags': 'NONE' },
          'Program Counter': { 'Action': 'PC = PC + 1' },
          'Memory': { 'Read': 'NO', 'Write': 'NO' },
          'Timing': { 'Cycles': '1', 'Pipeline': 'Execute while fetching next' }
        };
        break;
      case 'MOV':
        signals = {
          'Register File': { 'Read Port A': 'NONE', 'Read Port B': 'R17', 'Write Enable': 'YES', 'Write Port': 'R16' },
          'ALU': { 'Operation': 'PASS', 'Operand A Source': 'Rr', 'Operand B Source': 'NONE' },
          'SREG': { 'Update Flags': 'NONE' },
          'Program Counter': { 'Action': 'PC = PC + 1' },
          'Memory': { 'Read': 'NO', 'Write': 'NO' },
          'Timing': { 'Cycles': '1', 'Pipeline': 'Execute while fetching next' }
        };
        break;
      case 'ST':
        signals = {
          'Register File': { 'Read Port A': 'R16', 'Read Port B': 'X (R27:R26)', 'Write Enable': 'NO', 'Write Port': 'NONE' },
          'ALU': { 'Operation': 'PASS', 'Operand A Source': 'Rd', 'Operand B Source': 'NONE' },
          'SREG': { 'Update Flags': 'NONE' },
          'Program Counter': { 'Action': 'PC = PC + 1' },
          'Memory': { 'Read': 'NO', 'Write': 'YES', 'Address': 'X pointer', 'Data': 'R16' },
          'Timing': { 'Cycles': '2', 'Pipeline': 'Memory access takes extra cycle' }
        };
        break;
      case 'LD':
        signals = {
          'Register File': { 'Read Port A': 'NONE', 'Read Port B': 'X (R27:R26)', 'Write Enable': 'YES', 'Write Port': 'R16' },
          'ALU': { 'Operation': 'PASS', 'Operand A Source': 'Memory', 'Operand B Source': 'NONE' },
          'SREG': { 'Update Flags': 'NONE' },
          'Program Counter': { 'Action': 'PC = PC + 1' },
          'Memory': { 'Read': 'YES', 'Write': 'NO', 'Address': 'X pointer' },
          'Timing': { 'Cycles': '2', 'Pipeline': 'Memory access takes extra cycle' }
        };
        break;
    }

    setControlSignals(signals);
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-br from-indigo-900 to-indigo-800 p-6 rounded-xl border-2 border-indigo-500">
        <h3 className="text-2xl font-bold text-indigo-300 mb-4">⚙️ Control Unit Simulator</h3>
        <p className="text-indigo-200 mb-4">
          The control unit is the "brain" that orchestrates all CPU components. Select an instruction to see what control signals it generates!
        </p>

        {/* Instruction Selection */}
        <div className="grid md:grid-cols-2 gap-6 mb-6">
          <div className="bg-slate-950 p-5 rounded-lg border-2 border-indigo-500">
            <h4 className="text-lg font-bold text-indigo-300 mb-4">Select Instruction</h4>
            <div className="space-y-2">
              {instructions.map((inst) => (
                <button
                  key={inst.name}
                  onClick={() => setSelectedInstruction(inst.name)}
                  className={`w-full text-left p-3 rounded transition-all ${
                    selectedInstruction === inst.name
                      ? 'bg-indigo-600 text-white border-2 border-indigo-300'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  <div className="font-mono font-bold">{inst.full}</div>
                  <div className="text-xs opacity-75">{inst.desc}</div>
                </button>
              ))}
            </div>

            <button
              onClick={generateControlSignals}
              className="w-full mt-4 bg-gradient-to-r from-cyan-500 to-blue-500 text-white font-bold py-3 px-6 rounded-lg hover:from-cyan-600 hover:to-blue-600 transition-all transform hover:scale-105"
            >
              ⚡ Generate Control Signals
            </button>
          </div>

          {/* Current Instruction Display */}
          <div className="bg-gradient-to-br from-purple-900 to-purple-800 p-5 rounded-lg border-2 border-purple-500">
            <h4 className="text-lg font-bold text-purple-300 mb-4">Current Instruction</h4>
            <div className="bg-slate-950 p-6 rounded border-2 border-purple-600">
              <div className="text-center">
                <div className="text-sm text-purple-300 mb-2">Assembly</div>
                <div className="font-mono text-3xl font-bold text-white mb-4">
                  {instructions.find(i => i.name === selectedInstruction)?.full}
                </div>
                <div className="text-purple-200 text-sm">
                  {instructions.find(i => i.name === selectedInstruction)?.desc}
                </div>
              </div>
            </div>

            {controlSignals && (
              <div className="mt-4 bg-green-900 p-4 rounded border-2 border-green-500">
                <div className="flex items-center justify-center gap-2 text-green-300">
                  <span className="animate-pulse">⚡</span>
                  <span className="font-bold">Control Signals Active</span>
                  <span className="animate-pulse">⚡</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Control Signals Output */}
        {controlSignals && (
          <div className="space-y-4">
            <h4 className="text-xl font-bold text-indigo-300 mb-4">📡 Generated Control Signals</h4>
            
            <div className="grid md:grid-cols-2 gap-4">
              {Object.entries(controlSignals).map(([component, signals]: [string, any]) => (
                <div key={component} className="bg-gradient-to-br from-slate-900 to-slate-800 p-5 rounded-lg border-2 border-cyan-500">
                  <h5 className="text-lg font-bold text-cyan-300 mb-3">{component}</h5>
                  <div className="space-y-2">
                    {Object.entries(signals).map(([signal, value]: [string, any]) => (
                      <div key={signal} className="bg-slate-950 p-3 rounded border border-cyan-700">
                        <div className="flex justify-between items-center">
                          <span className="text-cyan-400 text-sm">{signal}:</span>
                          <span className={`font-mono font-bold ${
                            value === 'YES' || value.includes('R') ? 'text-green-400' : 
                            value === 'NO' || value === 'NONE' ? 'text-slate-500' :
                            'text-white'
                          }`}>
                            {value}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* How Control Unit Works */}
      <div className="bg-gradient-to-br from-amber-900 to-amber-800 p-6 rounded-lg border-2 border-amber-500">
        <h3 className="text-xl font-bold text-amber-300 mb-4">🧠 How the Control Unit Works</h3>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="bg-slate-950 p-4 rounded border border-amber-500">
              <h5 className="font-bold text-amber-300 mb-2">1. Receives Decoded Instruction</h5>
              <p className="text-sm text-amber-100">The instruction decoder sends the opcode and operand information to the control unit.</p>
            </div>

            <div className="bg-slate-950 p-4 rounded border border-amber-500">
              <h5 className="font-bold text-amber-300 mb-2">2. Finite State Machine (FSM)</h5>
              <p className="text-sm text-amber-100">The control unit is a hardwired FSM that transitions through states: Fetch → Decode → Execute → Write-back.</p>
            </div>

            <div className="bg-slate-950 p-4 rounded border border-amber-500">
              <h5 className="font-bold text-amber-300 mb-2">3. Generates Control Signals</h5>
              <p className="text-sm text-amber-100">Based on the instruction and current state, it activates specific control lines to coordinate all components.</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-slate-950 p-4 rounded border border-amber-500">
              <h5 className="font-bold text-amber-300 mb-2">4. Timing Control</h5>
              <p className="text-sm text-amber-100">Ensures all operations happen in the correct sequence, synchronized with the system clock.</p>
            </div>

            <div className="bg-slate-950 p-4 rounded border border-amber-500">
              <h5 className="font-bold text-amber-300 mb-2">5. Exception Handling</h5>
              <p className="text-sm text-amber-100">Detects interrupts and exceptions, saving state and jumping to interrupt vectors when needed.</p>
            </div>

            <div className="bg-slate-950 p-4 rounded border border-amber-500">
              <h5 className="font-bold text-amber-300 mb-2">6. Pipeline Management</h5>
              <p className="text-sm text-amber-100">Coordinates the 2-stage pipeline, ensuring fetch and execute stages don't conflict.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Control Signal Types */}
      <div className="bg-gradient-to-br from-blue-900 to-blue-800 p-6 rounded-lg border-2 border-blue-500">
        <h3 className="text-xl font-bold text-blue-300 mb-4">📋 Types of Control Signals</h3>
        
        <div className="grid md:grid-cols-3 gap-4">
          <div className="bg-slate-950 p-4 rounded border border-blue-500">
            <h5 className="text-blue-300 font-bold mb-2">Register Control</h5>
            <ul className="text-sm text-blue-200 space-y-1">
              <li>• Read enable (Rd, Rr)</li>
              <li>• Write enable</li>
              <li>• Register select</li>
              <li>• Port selection</li>
            </ul>
          </div>

          <div className="bg-slate-950 p-4 rounded border border-blue-500">
            <h5 className="text-blue-300 font-bold mb-2">ALU Control</h5>
            <ul className="text-sm text-blue-200 space-y-1">
              <li>• Operation select</li>
              <li>• Operand routing</li>
              <li>• Flag update enable</li>
              <li>• Carry input</li>
            </ul>
          </div>

          <div className="bg-slate-950 p-4 rounded border border-blue-500">
            <h5 className="text-blue-300 font-bold mb-2">Memory Control</h5>
            <ul className="text-sm text-blue-200 space-y-1">
              <li>• Read/Write enable</li>
              <li>• Address selection</li>
              <li>• Data routing</li>
              <li>• Bus control</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Performance Info */}
      <div className="bg-gradient-to-br from-green-900 to-green-800 p-6 rounded-lg border-2 border-green-500">
        <h3 className="text-xl font-bold text-green-300 mb-4">⚡ Why Hardwired Control?</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-slate-950 p-4 rounded border border-green-500">
            <h5 className="text-green-300 font-bold mb-2">✅ Advantages</h5>
            <ul className="text-sm text-green-200 space-y-1">
              <li>• <strong>Fast:</strong> Pure combinational logic, no memory lookups</li>
              <li>• <strong>Efficient:</strong> Most instructions execute in 1 cycle</li>
              <li>• <strong>Simple:</strong> Fixed instruction set, predictable timing</li>
              <li>• <strong>Low Power:</strong> Minimal transistor switching</li>
            </ul>
          </div>

          <div className="bg-slate-950 p-4 rounded border border-green-500">
            <h5 className="text-green-300 font-bold mb-2">📊 Comparison</h5>
            <div className="text-sm text-green-200 space-y-2">
              <div className="flex justify-between">
                <span>Hardwired (ATmega328P):</span>
                <span className="font-mono text-cyan-300">1 cycle</span>
              </div>
              <div className="flex justify-between">
                <span>Microcoded (older CPUs):</span>
                <span className="font-mono text-amber-300">3-5 cycles</span>
              </div>
              <p className="text-xs text-green-400 mt-2 pt-2 border-t border-green-700">
                The ATmega328P achieves 16 MIPS @ 16MHz because of its efficient hardwired control unit!
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
