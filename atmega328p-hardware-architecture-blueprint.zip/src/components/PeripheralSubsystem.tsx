import { ComponentType } from '../App';

interface Props {
  onHover: (component: string | null) => void;
  onZoom: (component: ComponentType) => void;
  hoveredComponent: string | null;
}

export default function PeripheralSubsystem({ onHover, onZoom, hoveredComponent }: Props) {
  const createPeripheral = (
    y: number,
    height: number,
    id: ComponentType,
    title: string,
    hoverText: string,
    children: React.ReactNode
  ) => (
    <g 
      className="cursor-pointer transition-all"
      onMouseEnter={() => onHover(hoverText)}
      onMouseLeave={() => onHover(null)}
      onClick={() => onZoom(id)}
      style={{ 
        filter: hoveredComponent?.includes(title.split(' ')[0]) ? 'url(#glow)' : 'none',
        opacity: hoveredComponent && !hoveredComponent.includes(title.split(' ')[0]) ? 0.5 : 1
      }}
    >
      <rect x="900" y={y} width="280" height={height} fill="#7C2D12" stroke="#F97316" strokeWidth="2" rx="6"
        className="hover:fill-orange-950 transition-colors"/>
      {children}
    </g>
  );

  return (
    <g id="peripherals">
      <text x="900" y="130" className="font-bold text-base fill-orange-400">PERIPHERALS</text>
      
      {/* GPIO Port B */}
      {createPeripheral(150, 75, 'gpio-b', 'GPIO B', 'GPIO Port B — 8 digital I/O pins',
        <>
          <text x="910" y="168" className="text-sm font-bold fill-orange-300">GPIO Port B</text>
          <text x="910" y="182" className="text-xs fill-orange-400">PB0-PB7 (D8-D13)</text>
          <text x="910" y="195" className="text-xs fill-cyan-300">PINB DDRB PORTB</text>
          <text x="910" y="208" className="text-xs fill-amber-300">PB5=LED D13</text>
        </>
      )}
      
      {/* GPIO Port C */}
      {createPeripheral(235, 70, 'gpio-c', 'GPIO C', 'GPIO Port C — 7 analog/digital pins',
        <>
          <text x="910" y="253" className="text-sm font-bold fill-orange-300">GPIO Port C</text>
          <text x="910" y="267" className="text-xs fill-orange-400">PC0-PC6 (A0-A5)</text>
          <text x="910" y="280" className="text-xs fill-cyan-300">PINC DDRC PORTC</text>
          <text x="910" y="293" className="text-xs fill-amber-300">ADC + I2C</text>
        </>
      )}
      
      {/* GPIO Port D */}
      {createPeripheral(315, 70, 'gpio-d', 'GPIO D', 'GPIO Port D — 8 digital I/O pins',
        <>
          <text x="910" y="333" className="text-sm font-bold fill-orange-300">GPIO Port D</text>
          <text x="910" y="347" className="text-xs fill-orange-400">PD0-PD7 (D0-D7)</text>
          <text x="910" y="360" className="text-xs fill-cyan-300">PIND DDRD PORTD</text>
          <text x="910" y="373" className="text-xs fill-amber-300">RX TX INT0 INT1</text>
        </>
      )}
      
      {/* Timer 0 */}
      {createPeripheral(395, 85, 'timer0', 'Timer 0', 'Timer 0 — 8-bit for millis() & PWM',
        <>
          <text x="910" y="413" className="text-sm font-bold fill-orange-300">Timer 0 — 8-bit</text>
          <text x="910" y="427" className="text-xs fill-orange-400">TCCR0A TCCR0B TCNT0</text>
          <text x="910" y="440" className="text-xs fill-cyan-300">OCR0A OCR0B</text>
          <text x="910" y="453" className="text-xs fill-green-300">millis() delay()</text>
          <text x="910" y="466" className="text-xs fill-amber-300">PWM: D5 D6</text>
        </>
      )}
      
      {/* Timer 1 */}
      {createPeripheral(490, 75, 'timer1', 'Timer 1', 'Timer 1 — 16-bit for Servo',
        <>
          <text x="910" y="508" className="text-sm font-bold fill-orange-300">Timer 1 — 16-bit</text>
          <text x="910" y="522" className="text-xs fill-orange-400">TCCR1A TCCR1B TCNT1</text>
          <text x="910" y="535" className="text-xs fill-cyan-300">OCR1A OCR1B ICR1</text>
          <text x="910" y="548" className="text-xs fill-green-300">Servo library</text>
          <text x="910" y="558" className="text-xs fill-amber-300">PWM: D9 D10</text>
        </>
      )}
      
      {/* Timer 2 */}
      {createPeripheral(575, 65, 'timer2', 'Timer 2', 'Timer 2 — 8-bit for tone()',
        <>
          <text x="910" y="593" className="text-sm font-bold fill-orange-300">Timer 2 — 8-bit</text>
          <text x="910" y="607" className="text-xs fill-orange-400">TCCR2A TCCR2B TCNT2</text>
          <text x="910" y="620" className="text-xs fill-green-300">tone() function</text>
          <text x="910" y="633" className="text-xs fill-amber-300">PWM: D3 D11</text>
        </>
      )}
      
      {/* USART */}
      {createPeripheral(650, 80, 'usart', 'USART', 'USART — Serial communication',
        <>
          <text x="910" y="668" className="text-sm font-bold fill-orange-300">USART Serial</text>
          <text x="910" y="682" className="text-xs fill-orange-400">UDR0 UBRR0 UCSR0</text>
          <text x="910" y="695" className="text-xs fill-cyan-300">TX(D1) RX(D0)</text>
          <text x="910" y="708" className="text-xs fill-green-300">Serial.print()</text>
          <text x="910" y="720" className="text-xs fill-amber-300">up to 2 Mbps</text>
        </>
      )}
      
      {/* SPI */}
      {createPeripheral(740, 70, 'spi', 'SPI', 'SPI — High-speed serial',
        <>
          <text x="910" y="758" className="text-sm font-bold fill-orange-300">SPI Interface</text>
          <text x="910" y="772" className="text-xs fill-orange-400">SPCR SPSR SPDR</text>
          <text x="910" y="785" className="text-xs fill-cyan-300">MOSI MISO SCK SS</text>
          <text x="910" y="798" className="text-xs fill-green-300">up to 8 MHz</text>
        </>
      )}
      
      {/* I2C */}
      {createPeripheral(820, 70, 'i2c', 'I2C', 'I2C — Two-wire bus',
        <>
          <text x="910" y="838" className="text-sm font-bold fill-orange-300">I2C / TWI</text>
          <text x="910" y="852" className="text-xs fill-orange-400">TWCR TWDR TWAR</text>
          <text x="910" y="865" className="text-xs fill-cyan-300">SDA(A4) SCL(A5)</text>
          <text x="910" y="878" className="text-xs fill-green-300">127 devices</text>
        </>
      )}
      
      {/* ADC */}
      {createPeripheral(900, 95, 'adc', 'ADC', 'ADC — 10-bit converter',
        <>
          <text x="910" y="918" className="text-sm font-bold fill-orange-300">ADC 10-bit</text>
          <text x="910" y="932" className="text-xs fill-orange-400">ADMUX ADCSRA</text>
          <text x="910" y="945" className="text-xs fill-cyan-300">6 channels A0-A5</text>
          <text x="910" y="958" className="text-xs fill-green-300">4.88mV/step @5V</text>
          <text x="910" y="971" className="text-xs fill-amber-300">104µs conversion</text>
          <text x="910" y="984" className="text-xs fill-purple-300">analogRead()</text>
        </>
      )}
      
      {/* Watchdog */}
      {createPeripheral(1005, 75, 'watchdog', 'Watchdog', 'Watchdog — Reset protection',
        <>
          <text x="910" y="1023" className="text-sm font-bold fill-orange-300">Watchdog Timer</text>
          <text x="910" y="1037" className="text-xs fill-orange-400">WDTCSR</text>
          <text x="910" y="1050" className="text-xs fill-cyan-300">128kHz oscillator</text>
          <text x="910" y="1063" className="text-xs fill-green-300">15ms - 8s timeout</text>
          <text x="910" y="1073" className="text-xs fill-amber-300">System protection</text>
        </>
      )}
    </g>
  );
}
