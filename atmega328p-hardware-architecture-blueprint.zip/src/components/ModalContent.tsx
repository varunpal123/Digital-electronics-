export function createDarkCard(title: string, children: React.ReactNode, color: 'blue' | 'green' | 'amber' | 'purple' | 'red' | 'cyan' = 'blue') {
  const colors = {
    blue: 'from-blue-900 to-blue-800 border-blue-500',
    green: 'from-green-900 to-green-800 border-green-500',
    amber: 'from-amber-900 to-amber-800 border-amber-500',
    purple: 'from-purple-900 to-purple-800 border-purple-500',
    red: 'from-red-900 to-red-800 border-red-500',
    cyan: 'from-cyan-900 to-cyan-800 border-cyan-500'
  };

  return (
    <div className={`bg-gradient-to-br ${colors[color]} p-6 rounded-lg border-2`}>
      <h3 className="text-xl font-bold text-white mb-4">{title}</h3>
      <div className="text-slate-200 space-y-2">
        {children}
      </div>
    </div>
  );
}

export function CodeBlock({ children }: { children: string }) {
  return (
    <div className="bg-slate-950 text-green-400 p-4 rounded-lg font-mono text-sm border border-slate-700 overflow-x-auto">
      <pre className="whitespace-pre-wrap">{children}</pre>
    </div>
  );
}

export function InfoBox({ title, items, color = 'blue' }: { title: string; items: string[]; color?: 'blue' | 'green' | 'amber' | 'red' | 'cyan' }) {
  const textColors = {
    blue: 'text-blue-300',
    green: 'text-green-300',
    amber: 'text-amber-300',
    red: 'text-red-300',
    cyan: 'text-cyan-300'
  };

  return (
    <div>
      <p className={`font-semibold ${textColors[color]} mb-2`}>{title}</p>
      <ul className="space-y-1 text-sm text-slate-300">
        {items.map((item, idx) => (
          <li key={idx}>• {item}</li>
        ))}
      </ul>
    </div>
  );
}
