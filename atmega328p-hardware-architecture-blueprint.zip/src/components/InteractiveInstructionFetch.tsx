import { useState, useEffect } from 'react';

export default function InteractiveInstructionFetch() {
  const [pc, setPC] = useState(0x0000);
  const [isAnimating, setIsAnimating] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);

  // Sample program in Flash memory
  const flashMemory = [
    { addr: 0x0000, instruction: 0xE000, asm: 'LDI R16, 0', description: 'Load immediate 0 into R16' },
    { addr: 0x0001, instruction: 0xEF0F, asm: 'LDI R17, 255', description: 'Load immediate 255 into R17' },
    { addr: 0x0002, instruction: 0x0F01, asm: 'ADD R16, R17', description: 'Add R17 to R16' },
    { addr: 0x0003, instruction: 0x9508, asm: 'RET', description: 'Return from subroutine' },
    { addr: 0x0004, instruction: 0x940C, asm: 'JMP 0x000', description: 'Jump to address 0' },
  ];

  const steps = [
    'PC points to Flash address',
    'Address sent to Flash memory',
    'Flash outputs 16-bit instruction',
    'Instruction loaded into IR',
    'PC incremented (PC + 1)',
    'Ready for next fetch'
  ];

  useEffect(() => {
    if (isAnimating) {
      const timer = setTimeout(() => {
        if (currentStep < steps.length - 1) {
          setCurrentStep(currentStep + 1);
        } else {
          setCurrentStep(0);
          setIsAnimating(false);
        }
      }, 800);
      return () => clearTimeout(timer);
    }
  }, [isAnimating, currentStep]);

  const startFetch = () => {
    setCurrentStep(0);
    setIsAnimating(true);
  };

  const handlePCChange = (newPC: number) => {
    if (newPC >= 0 && newPC < flashMemory.length) {
      setPC(newPC);
    }
  };

  const currentInstruction = flashMemory[pc];

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-br from-blue-900 to-blue-800 p-6 rounded-xl border-2 border-blue-500">
        <h3 className="text-2xl font-bold text-blue-300 mb-4">📥 Instruction Fetch Simulator</h3>
        <p className="text-blue-200 mb-4">
          Watch how the CPU fetches instructions from Flash memory step by step!
        </p>

        {/* PC Control */}
        <div className="bg-slate-950 p-6 rounded-lg border-2 border-cyan-500 mb-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h4 className="text-xl font-bold text-cyan-300">Program Counter (PC)</h4>
              <p className="text-cyan-400 text-sm">Points to the next instruction to fetch</p>
            </div>
            <div className="text-4xl font-mono font-bold text-cyan-300">
              0x{pc.toString(16).toUpperCase().padStart(4, '0')}
            </div>
          </div>
          
          <div className="flex gap-2">
            <button
              onClick={() => handlePCChange(pc - 1)}
              disabled={pc === 0}
              className="px-4 py-2 bg-slate-700 text-white rounded hover:bg-slate-600 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              ← Prev
            </button>
            <button
              onClick={() => handlePCChange(0)}
              className="px-4 py-2 bg-slate-700 text-white rounded hover:bg-slate-600"
            >
              Reset
            </button>
            <button
              onClick={() => handlePCChange(pc + 1)}
              disabled={pc >= flashMemory.length - 1}
              className="px-4 py-2 bg-slate-700 text-white rounded hover:bg-slate-600 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Next →
            </button>
            <button
              onClick={startFetch}
              disabled={isAnimating}
              className="ml-auto px-6 py-2 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold rounded hover:from-green-600 hover:to-emerald-600 disabled:opacity-50"
            >
              ▶ Animate Fetch
            </button>
          </div>
        </div>

        {/* Fetch Animation */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Flash Memory */}
          <div className="bg-gradient-to-br from-green-900 to-green-800 p-6 rounded-lg border-2 border-green-500">
            <h4 className="text-xl font-bold text-green-300 mb-4">Flash Memory (32KB)</h4>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {flashMemory.map((mem, idx) => (
                <div
                  key={idx}
                  className={`p-3 rounded font-mono text-sm transition-all ${
                    idx === pc
                      ? isAnimating && currentStep >= 1 && currentStep <= 2
                        ? 'bg-yellow-500 text-black animate-pulse'
                        : 'bg-cyan-600 text-white border-2 border-cyan-300'
                      : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span className="text-xs opacity-70">0x{mem.addr.toString(16).toUpperCase().padStart(4, '0')}</span>
                    <span className="font-bold">0x{mem.instruction.toString(16).toUpperCase().padStart(4, '0')}</span>
                  </div>
                  <div className="text-xs mt-1 opacity-90">{mem.asm}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Instruction Register */}
          <div className="space-y-4">
            <div className={`bg-gradient-to-br from-purple-900 to-purple-800 p-6 rounded-lg border-2 transition-all ${
              isAnimating && currentStep >= 3 ? 'border-yellow-400 shadow-lg shadow-yellow-400/50' : 'border-purple-500'
            }`}>
              <h4 className="text-xl font-bold text-purple-300 mb-4">Instruction Register (IR)</h4>
              <div className="bg-slate-950 p-4 rounded border-2 border-purple-500">
                <div className="text-center mb-2">
                  <div className="text-sm text-purple-300">16-bit Instruction</div>
                  <div className="text-3xl font-mono font-bold text-purple-400 my-2">
                    {isAnimating && currentStep >= 3 ? `0x${currentInstruction.instruction.toString(16).toUpperCase().padStart(4, '0')}` : '----'}
                  </div>
                </div>
                <div className="border-t border-purple-700 pt-3 mt-3">
                  <div className="text-xs text-purple-300 mb-1">Assembly:</div>
                  <div className="font-mono text-green-400">{isAnimating && currentStep >= 3 ? currentInstruction.asm : '---'}</div>
                  <div className="text-xs text-slate-400 mt-2">
                    {isAnimating && currentStep >= 3 ? currentInstruction.description : 'Waiting for instruction...'}
                  </div>
                </div>
              </div>
            </div>

            {/* Binary Representation */}
            <div className="bg-slate-800 p-4 rounded-lg border border-slate-600">
              <h5 className="text-sm font-bold text-cyan-300 mb-2">Binary Breakdown:</h5>
              {isAnimating && currentStep >= 3 ? (
                <div className="font-mono text-xs text-green-400 space-y-1">
                  <div>{currentInstruction.instruction.toString(2).padStart(16, '0').match(/.{1,4}/g)?.join(' ')}</div>
                  <div className="text-slate-400">
                    {currentInstruction.instruction.toString(2).padStart(16, '0').split('').map((bit, i) => (
                      <span key={i} className={bit === '1' ? 'text-green-400' : 'text-slate-600'}>
                        {i % 4 === 0 && i > 0 ? ' ' : ''}{bit}
                      </span>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-slate-500 text-sm">No instruction loaded</div>
              )}
            </div>
          </div>
        </div>

        {/* Fetch Steps */}
        <div className="mt-6 bg-slate-800 p-6 rounded-lg border border-slate-600">
          <h4 className="text-lg font-bold text-cyan-300 mb-4">Fetch Sequence:</h4>
          <div className="space-y-2">
            {steps.map((step, idx) => (
              <div
                key={idx}
                className={`flex items-center gap-3 p-3 rounded transition-all ${
                  isAnimating && currentStep === idx
                    ? 'bg-green-600 text-white'
                    : isAnimating && currentStep > idx
                    ? 'bg-green-900 text-green-300'
                    : 'bg-slate-700 text-slate-400'
                }`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                  isAnimating && currentStep >= idx ? 'bg-green-500 text-white' : 'bg-slate-600 text-slate-400'
                }`}>
                  {idx + 1}
                </div>
                <div className="flex-1">{step}</div>
                {isAnimating && currentStep === idx && (
                  <div className="text-yellow-300 animate-pulse">⚡</div>
                )}
                {isAnimating && currentStep > idx && (
                  <div className="text-green-300">✓</div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Technical Details */}
      <div className="bg-gradient-to-br from-amber-900 to-amber-800 p-6 rounded-lg border-2 border-amber-500">
        <h3 className="text-xl font-bold text-amber-300 mb-3">⚡ Performance Facts</h3>
        <div className="grid md:grid-cols-3 gap-4 text-sm">
          <div className="bg-slate-950 p-4 rounded border border-amber-500">
            <div className="text-amber-300 font-bold mb-2">Fetch Time</div>
            <div className="text-white text-2xl font-mono">1 cycle</div>
            <div className="text-amber-200 text-xs mt-1">62.5 nanoseconds @ 16MHz</div>
          </div>
          <div className="bg-slate-950 p-4 rounded border border-amber-500">
            <div className="text-amber-300 font-bold mb-2">Bus Width</div>
            <div className="text-white text-2xl font-mono">16-bit</div>
            <div className="text-amber-200 text-xs mt-1">Full instruction per fetch</div>
          </div>
          <div className="bg-slate-950 p-4 rounded border border-amber-500">
            <div className="text-amber-300 font-bold mb-2">Pipeline</div>
            <div className="text-white text-2xl font-mono">2-stage</div>
            <div className="text-amber-200 text-xs mt-1">Fetch while executing</div>
          </div>
        </div>
      </div>
    </div>
  );
}
