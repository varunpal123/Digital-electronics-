import { ComponentType } from '../App';
import { X } from 'lucide-react';
import InteractiveALU from './InteractiveALU';
import InteractiveInstructionFetch from './InteractiveInstructionFetch';
import InteractiveDecoder from './InteractiveDecoder';
import InteractiveControlUnit from './InteractiveControlUnit';

interface Props {
  component: ComponentType;
  onClose: () => void;
}

export default function ZoomModal({ component, onClose }: Props) {
  const getComponentDetails = () => {
    switch (component) {
      case 'cpu-core':
        return {
          title: 'AVR CPU Core',
          description: 'The heart of the ATmega328P - executing instructions and managing data flow'
        };
      case 'flash':
        return {
          title: 'Flash Program Memory - 32KB',
          description: 'Non-volatile memory storing your Arduino program'
        };
      case 'sram':
        return {
          title: 'SRAM - 2KB',
          description: 'Volatile memory for variables, arrays, and stack'
        };
      case 'eeprom':
        return {
          title: 'EEPROM - 1KB',
          description: 'Non-volatile memory for persistent data storage'
        };
      case 'alu':
        return {
          title: 'Arithmetic Logic Unit (ALU)',
          description: 'Performs all arithmetic and logical operations'
        };
      case 'register-file':
        return {
          title: 'Register File - 32 × 8-bit GPR',
          description: 'Fast storage directly accessible by CPU instructions'
        };
      case 'timer0':
        return {
          title: 'Timer 0 - 8-bit Timer/Counter',
          description: 'Drives millis(), delay(), and PWM on pins 5 and 6'
        };
      case 'timer1':
        return {
          title: 'Timer 1 - 16-bit Timer/Counter',
          description: 'High-resolution timing and PWM for Servo library'
        };
      case 'timer2':
        return {
          title: 'Timer 2 - 8-bit Timer/Counter',
          description: 'Independent timer used by tone() function'
        };
      case 'usart':
        return {
          title: 'USART - Universal Serial',
          description: 'Hardware serial communication (Serial.print, Serial.read)'
        };
      case 'spi':
        return {
          title: 'SPI - Serial Peripheral Interface',
          description: 'High-speed synchronous communication protocol'
        };
      case 'i2c':
        return {
          title: 'I2C/TWI - Two-Wire Interface',
          description: 'Multi-device bus communication with 2 wires'
        };
      case 'adc':
        return {
          title: 'ADC - 10-bit Analog to Digital Converter',
          description: 'Converts analog voltages (0-5V) to digital values (0-1023)'
        };
      case 'watchdog':
        return {
          title: 'Watchdog Timer',
          description: 'System reset protection against software crashes'
        };
      case 'gpio-b':
      case 'gpio-c':
      case 'gpio-d':
        return {
          title: `GPIO Port ${component.split('-')[1].toUpperCase()}`,
          description: 'General Purpose Input/Output pins for digital signals'
        };
      case 'interrupt':
        return {
          title: 'Interrupt System',
          description: 'Hardware interrupt handling with 26 vector entries'
        };
      default:
        return { title: 'Component Details', description: '' };
    }
  };

  const details = getComponentDetails();

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50 p-4 animate-fadeIn backdrop-blur-sm"
      onClick={onClose}
    >
      <div 
        className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-2xl shadow-2xl max-w-6xl w-full max-h-[90vh] overflow-y-auto border-2 border-cyan-500"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white p-6 rounded-t-2xl flex justify-between items-start z-10 border-b-2 border-cyan-400">
          <div>
            <h2 className="text-3xl font-bold mb-2">{details.title}</h2>
            <p className="text-cyan-200">{details.description}</p>
          </div>
          <button 
            onClick={onClose}
            className="hover:bg-white hover:bg-opacity-20 p-2 rounded-lg transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        {/* Content */}
        <div className="p-8 bg-slate-900">
          {component === 'cpu-core' && <CPUCoreDetails />}
          {component === 'flash' && <FlashDetails />}
          {component === 'sram' && <SRAMDetails />}
          {component === 'eeprom' && <EEPROMDetails />}
          {component === 'alu' && <ALUDetails />}
          {component === 'register-file' && <RegisterFileDetails />}
          {component === 'timer0' && <Timer0Details />}
          {component === 'timer1' && <Timer1Details />}
          {component === 'timer2' && <Timer2Details />}
          {component === 'usart' && <USARTDetails />}
          {component === 'spi' && <SPIDetails />}
          {component === 'i2c' && <I2CDetails />}
          {component === 'adc' && <ADCDetails />}
          {component === 'watchdog' && <WatchdogDetails />}
          {(component === 'gpio-b' || component === 'gpio-c' || component === 'gpio-d') && <GPIODetails port={component.split('-')[1].toUpperCase()} />}
          {component === 'interrupt' && <InterruptDetails />}
        </div>
      </div>
    </div>
  );
}

// Detailed component views
function FlashDetails() {
  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-gradient-to-br from-green-900 to-green-800 p-6 rounded-lg border-2 border-green-500">
          <h3 className="text-xl font-bold text-green-300 mb-3">📦 Memory Organization</h3>
          <ul className="space-y-2 text-sm text-green-200">
            <li>• <strong className="text-green-300">Total Size:</strong> 32,768 bytes (32KB)</li>
            <li>• <strong className="text-green-300">Word Size:</strong> 16 bits per instruction</li>
            <li>• <strong className="text-green-300">Address Range:</strong> 0x0000 to 0x7FFF</li>
            <li>• <strong className="text-green-300">Bootloader:</strong> Last 512 bytes (optional)</li>
            <li>• <strong className="text-green-300">Write Cycles:</strong> 10,000 minimum</li>
          </ul>
        </div>

        <div className="bg-gradient-to-br from-amber-900 to-amber-800 p-6 rounded-lg border-2 border-amber-500">
          <h3 className="text-xl font-bold text-amber-300 mb-3">🎯 Interrupt Vectors</h3>
          <ul className="space-y-1 text-sm text-amber-200 font-mono">
            <li>0x0000: RESET</li>
            <li>0x0002: INT0 (External)</li>
            <li>0x0004: INT1 (External)</li>
            <li>0x0006 - 0x0032: 24 more vectors</li>
            <li>0x0034+: Your application code</li>
          </ul>
        </div>
      </div>

      <div className="bg-blue-50 p-6 rounded-lg border-2 border-blue-300">
        <h3 className="text-xl font-bold text-blue-900 mb-3">💡 Programming Tips</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-blue-800 mb-2"><strong>Upload Process:</strong></p>
            <ol className="text-sm text-blue-700 space-y-1">
              <li>1. Arduino IDE compiles .ino to .hex</li>
              <li>2. avrdude uploads via USB/Serial</li>
              <li>3. Bootloader writes to Flash</li>
              <li>4. Program starts at 0x0000 on reset</li>
            </ol>
          </div>
          <div>
            <p className="text-sm text-blue-800 mb-2"><strong>Code Storage:</strong></p>
            <ul className="text-sm text-blue-700 space-y-1">
              <li>• All your functions and constants</li>
              <li>• String literals (F() macro)</li>
              <li>• ISR (interrupt service routines)</li>
              <li>• Can't be modified at runtime</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="bg-gray-100 p-4 rounded-lg">
        <p className="text-sm text-gray-700">
          <strong>Note:</strong> Flash memory is non-volatile, meaning your program stays even when power is removed. 
          The ATmega328P can survive ~10,000 upload cycles before flash degradation.
        </p>
      </div>
    </div>
  );
}

function SRAMDetails() {
  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-blue-50 p-6 rounded-lg border-2 border-blue-300">
          <h3 className="text-xl font-bold text-blue-900 mb-3">📊 Memory Layout</h3>
          <div className="space-y-2 text-sm text-blue-800 font-mono">
            <div className="flex justify-between bg-blue-100 p-2 rounded">
              <span>0x08FF</span>
              <span>← Stack Pointer (SP) starts here</span>
            </div>
            <div className="text-center py-2">↓ Stack grows downward ↓</div>
            <div className="bg-red-100 p-2 rounded text-center text-red-700">
              ⚠️ COLLISION ZONE ⚠️
            </div>
            <div className="text-center py-2">↑ Heap/Variables grow upward ↑</div>
            <div className="flex justify-between bg-blue-100 p-2 rounded">
              <span>0x0100</span>
              <span>← Variables start here</span>
            </div>
          </div>
        </div>

        <div className="bg-purple-50 p-6 rounded-lg border-2 border-purple-300">
          <h3 className="text-xl font-bold text-purple-900 mb-3">⚙️ What's Stored Here</h3>
          <ul className="space-y-2 text-sm text-purple-800">
            <li>• <strong>Global variables:</strong> int, float, arrays</li>
            <li>• <strong>Local variables:</strong> function scope</li>
            <li>• <strong>Dynamic memory:</strong> malloc(), new</li>
            <li>• <strong>Stack frames:</strong> return addresses</li>
            <li>• <strong>String buffers:</strong> NOT F() strings</li>
          </ul>
        </div>
      </div>

      <div className="bg-red-50 p-6 rounded-lg border-2 border-red-300">
        <h3 className="text-xl font-bold text-red-900 mb-3">⚠️ Common Problems</h3>
        <div className="space-y-3">
          <div className="bg-white p-4 rounded">
            <p className="font-semibold text-red-800 mb-2">Stack Overflow:</p>
            <p className="text-sm text-red-700">
              Too many nested function calls or large local arrays can exhaust stack space.
              Symptoms: random crashes, strange behavior, corrupted variables.
            </p>
          </div>
          <div className="bg-white p-4 rounded">
            <p className="font-semibold text-red-800 mb-2">Heap Exhaustion:</p>
            <p className="text-sm text-red-700">
              Using String objects, large buffers, or malloc() without free() fills heap.
              Monitor with <code className="bg-red-100 px-1">freeMemory()</code> function.
            </p>
          </div>
        </div>
      </div>

      <div className="bg-green-50 p-6 rounded-lg border-2 border-green-300">
        <h3 className="text-xl font-bold text-green-900 mb-3">✅ Memory Optimization Tips</h3>
        <ul className="space-y-2 text-sm text-green-800">
          <li>• Use <code className="bg-green-100 px-1">const</code> for constants (stored in Flash, not SRAM)</li>
          <li>• Use <code className="bg-green-100 px-1">F()</code> macro for strings: <code>Serial.println(F("Hello"));</code></li>
          <li>• Prefer smaller data types: byte instead of int when possible</li>
          <li>• Avoid String class - use char arrays instead</li>
          <li>• Clear buffers when done: <code className="bg-green-100 px-1">memset(buffer, 0, size);</code></li>
          <li>• Only 2KB total - every byte counts!</li>
        </ul>
      </div>
    </div>
  );
}

function EEPROMDetails() {
  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-amber-50 p-6 rounded-lg border-2 border-amber-300">
          <h3 className="text-xl font-bold text-amber-900 mb-3">🔒 Characteristics</h3>
          <ul className="space-y-2 text-sm text-amber-800">
            <li>• <strong>Size:</strong> 1024 bytes (1KB)</li>
            <li>• <strong>Address Range:</strong> 0x000 to 0x3FF</li>
            <li>• <strong>Write Endurance:</strong> 100,000 cycles</li>
            <li>• <strong>Write Time:</strong> ~3.4ms per byte</li>
            <li>• <strong>Read Time:</strong> Instant (same as SRAM)</li>
            <li>• <strong>Retention:</strong> 100+ years</li>
          </ul>
        </div>

        <div className="bg-blue-50 p-6 rounded-lg border-2 border-blue-300">
          <h3 className="text-xl font-bold text-blue-900 mb-3">📝 Arduino Usage</h3>
          <div className="bg-gray-800 text-green-400 p-4 rounded font-mono text-xs space-y-2">
            <div className="text-gray-400">// Include library</div>
            <div>#include &lt;EEPROM.h&gt;</div>
            <div className="mt-2 text-gray-400">// Write a byte</div>
            <div>EEPROM.write(0, 255);</div>
            <div className="mt-2 text-gray-400">// Read a byte</div>
            <div>byte value = EEPROM.read(0);</div>
            <div className="mt-2 text-gray-400">// Update (only writes if changed)</div>
            <div>EEPROM.update(0, newValue);</div>
          </div>
        </div>
      </div>

      <div className="bg-green-50 p-6 rounded-lg border-2 border-green-300">
        <h3 className="text-xl font-bold text-green-900 mb-3">✅ Best Practices</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <ul className="space-y-2 text-sm text-green-800">
            <li>• Store configuration settings</li>
            <li>• Save sensor calibration data</li>
            <li>• Remember last state before power loss</li>
            <li>• Keep counters that survive reboot</li>
          </ul>
          <ul className="space-y-2 text-sm text-red-800">
            <li>• ❌ Don't write in loops (wear leveling!)</li>
            <li>• ❌ Don't store rapidly changing data</li>
            <li>• ❌ Avoid logging (use SD card instead)</li>
            <li>• ❌ Not for temporary variables</li>
          </ul>
        </div>
      </div>

      <div className="bg-purple-50 p-6 rounded-lg border-2 border-purple-300">
        <h3 className="text-xl font-bold text-purple-900 mb-3">🎯 Common Use Cases</h3>
        <div className="grid md:grid-cols-3 gap-4 text-sm">
          <div className="bg-white p-4 rounded">
            <p className="font-semibold text-purple-800 mb-2">🔐 Wi-Fi Credentials</p>
            <p className="text-purple-700">Store SSID and password so they survive power cycles</p>
          </div>
          <div className="bg-white p-4 rounded">
            <p className="font-semibold text-purple-800 mb-2">⚙️ User Settings</p>
            <p className="text-purple-700">LED brightness, alarm times, preferences</p>
          </div>
          <div className="bg-white p-4 rounded">
            <p className="font-semibold text-purple-800 mb-2">📈 Statistics</p>
            <p className="text-purple-700">Total runtime hours, boot count, high scores</p>
          </div>
        </div>
      </div>

      <div className="bg-red-50 p-4 rounded-lg border border-red-300">
        <p className="text-sm text-red-800">
          <strong>⚠️ Warning:</strong> Each EEPROM cell has ~100,000 write cycles. Writing the same address 
          every second would wear it out in ~1 day. Use <code className="bg-red-100 px-1">EEPROM.update()</code> 
          instead of <code className="bg-red-100 px-1">write()</code> to minimize writes.
        </p>
      </div>
    </div>
  );
}

function ALUDetails() {
  return (
    <div className="space-y-6">
      <InteractiveALU />
      <div className="bg-gradient-to-br from-blue-900 to-purple-900 p-6 rounded-lg border-2 border-blue-500">
        <h3 className="text-2xl font-bold text-blue-900 mb-4">🧮 Operations Performed</h3>
        <div className="grid md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-lg">
            <h4 className="font-bold text-blue-800 mb-2">Arithmetic</h4>
            <ul className="text-sm space-y-1 text-blue-700">
              <li>• ADD (with/without carry)</li>
              <li>• SUB (with/without carry)</li>
              <li>• INC (increment)</li>
              <li>• DEC (decrement)</li>
              <li>• NEG (negate)</li>
              <li>• MUL (multiply)</li>
            </ul>
          </div>
          <div className="bg-white p-4 rounded-lg">
            <h4 className="font-bold text-green-800 mb-2">Logical</h4>
            <ul className="text-sm space-y-1 text-green-700">
              <li>• AND</li>
              <li>• OR</li>
              <li>• EOR (XOR)</li>
              <li>• COM (complement)</li>
              <li>• NEG</li>
            </ul>
          </div>
          <div className="bg-white p-4 rounded-lg">
            <h4 className="font-bold text-purple-800 mb-2">Shift/Rotate</h4>
            <ul className="text-sm space-y-1 text-purple-700">
              <li>• LSL (logical shift left)</li>
              <li>• LSR (logical shift right)</li>
              <li>• ASR (arithmetic shift)</li>
              <li>• ROL (rotate left)</li>
              <li>• ROR (rotate right)</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-yellow-50 p-6 rounded-lg border-2 border-yellow-300">
          <h3 className="text-xl font-bold text-yellow-900 mb-3">⚡ Performance</h3>
          <ul className="space-y-2 text-sm text-yellow-800">
            <li>• <strong>8-bit operations:</strong> 1 clock cycle</li>
            <li>• <strong>Multiply:</strong> 2 clock cycles</li>
            <li>• <strong>16-bit math:</strong> Multiple instructions</li>
            <li>• <strong>Division:</strong> Software library (slow)</li>
            <li>• <strong>Throughput:</strong> 16 MIPS @ 16MHz</li>
          </ul>
        </div>

        <div className="bg-red-50 p-6 rounded-lg border-2 border-red-300">
          <h3 className="text-xl font-bold text-red-900 mb-3">🚩 Status Flags (SREG)</h3>
          <div className="space-y-2 text-sm font-mono">
            <div className="flex justify-between bg-white p-2 rounded">
              <span className="font-bold text-red-600">C</span>
              <span className="text-red-800">Carry flag</span>
            </div>
            <div className="flex justify-between bg-white p-2 rounded">
              <span className="font-bold text-red-600">Z</span>
              <span className="text-red-800">Zero flag</span>
            </div>
            <div className="flex justify-between bg-white p-2 rounded">
              <span className="font-bold text-red-600">N</span>
              <span className="text-red-800">Negative flag</span>
            </div>
            <div className="flex justify-between bg-white p-2 rounded">
              <span className="font-bold text-red-600">V</span>
              <span className="text-red-800">Overflow flag</span>
            </div>
            <div className="flex justify-between bg-white p-2 rounded">
              <span className="font-bold text-red-600">H</span>
              <span className="text-red-800">Half carry (BCD)</span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-blue-50 p-6 rounded-lg border-2 border-blue-300">
        <h3 className="text-xl font-bold text-blue-900 mb-3">📖 Example Operation Flow</h3>
        <div className="bg-gray-800 text-green-400 p-4 rounded font-mono text-sm space-y-2">
          <div className="text-gray-400">// ADD R16, R17 instruction</div>
          <div className="grid grid-cols-3 gap-4 mt-2 text-xs">
            <div>
              <div className="text-yellow-400">1. Fetch operands</div>
              <div>R16 = 0x7F</div>
              <div>R17 = 0x01</div>
            </div>
            <div>
              <div className="text-yellow-400">2. ALU computes</div>
              <div>0x7F + 0x01</div>
              <div>= 0x80</div>
            </div>
            <div>
              <div className="text-yellow-400">3. Update flags</div>
              <div className="text-red-400">N=1 (negative)</div>
              <div className="text-red-400">V=1 (overflow)</div>
              <div className="text-red-400">C=0 (no carry)</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function RegisterFileDetails() {
  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-lg border-2 border-blue-300">
        <h3 className="text-2xl font-bold text-blue-900 mb-4">📋 32 General Purpose Registers</h3>
        <div className="grid md:grid-cols-4 gap-2 font-mono text-sm">
          {Array.from({ length: 32 }, (_, i) => (
            <div key={i} className={`p-2 rounded ${i >= 26 ? 'bg-yellow-100 border-2 border-yellow-400' : 'bg-white border border-blue-200'}`}>
              <span className="font-bold text-blue-700">R{i}</span>
              {i === 26 && <span className="text-xs text-yellow-700 ml-2">XL</span>}
              {i === 27 && <span className="text-xs text-yellow-700 ml-2">XH</span>}
              {i === 28 && <span className="text-xs text-yellow-700 ml-2">YL</span>}
              {i === 29 && <span className="text-xs text-yellow-700 ml-2">YH</span>}
              {i === 30 && <span className="text-xs text-yellow-700 ml-2">ZL</span>}
              {i === 31 && <span className="text-xs text-yellow-700 ml-2">ZH</span>}
            </div>
          ))}
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-yellow-50 p-6 rounded-lg border-2 border-yellow-300">
          <h3 className="text-xl font-bold text-yellow-900 mb-3">🎯 16-bit Pointer Registers</h3>
          <div className="space-y-3">
            <div className="bg-white p-3 rounded">
              <p className="font-mono font-bold text-yellow-800">X = R27:R26</p>
              <p className="text-sm text-yellow-700">Indirect addressing, general pointer</p>
            </div>
            <div className="bg-white p-3 rounded">
              <p className="font-mono font-bold text-yellow-800">Y = R29:R28</p>
              <p className="text-sm text-yellow-700">Indirect with displacement (+q)</p>
            </div>
            <div className="bg-white p-3 rounded">
              <p className="font-mono font-bold text-yellow-800">Z = R31:R30</p>
              <p className="text-sm text-yellow-700">Indirect addressing + LPM/SPM</p>
            </div>
          </div>
        </div>

        <div className="bg-green-50 p-6 rounded-lg border-2 border-green-300">
          <h3 className="text-xl font-bold text-green-900 mb-3">⚡ Speed Advantage</h3>
          <ul className="space-y-2 text-sm text-green-800">
            <li>• <strong>Register access:</strong> 1 cycle</li>
            <li>• <strong>SRAM access:</strong> 2 cycles</li>
            <li>• <strong>Flash access:</strong> 3 cycles</li>
            <li className="pt-2 border-t border-green-300">• Compiler tries to keep variables in registers</li>
            <li>• Critical for loop counters and accumulators</li>
            <li>• R0-R1 reserved for MUL result</li>
          </ul>
        </div>
      </div>

      <div className="bg-purple-50 p-6 rounded-lg border-2 border-purple-300">
        <h3 className="text-xl font-bold text-purple-900 mb-3">📚 Dual Read Ports Architecture</h3>
        <p className="text-sm text-purple-800 mb-4">
          The register file has two independent read ports and one write port, allowing instructions 
          to read two operands simultaneously in a single clock cycle.
        </p>
        <div className="bg-white p-4 rounded font-mono text-sm">
          <div className="text-gray-600">Example: ADD R16, R17</div>
          <div className="mt-2 grid grid-cols-3 gap-4 text-xs">
            <div className="bg-blue-100 p-2 rounded">
              <div className="font-bold text-blue-800">Read Port A</div>
              <div className="text-blue-700">R16 (Rd)</div>
            </div>
            <div className="bg-blue-100 p-2 rounded">
              <div className="font-bold text-blue-800">Read Port B</div>
              <div className="text-blue-700">R17 (Rr)</div>
            </div>
            <div className="bg-green-100 p-2 rounded">
              <div className="font-bold text-green-800">Write Port</div>
              <div className="text-green-700">R16 (result)</div>
            </div>
          </div>
          <div className="mt-3 text-gray-700 text-xs">
            ✅ All three operations happen in parallel - that's why most instructions execute in 1 cycle!
          </div>
        </div>
      </div>

      <div className="bg-blue-50 p-4 rounded-lg border border-blue-300">
        <p className="text-sm text-blue-800">
          <strong>💡 Pro Tip:</strong> Use local variables in time-critical functions. The compiler will likely 
          allocate them to registers (R18-R27 typically) for faster execution compared to global variables in SRAM.
        </p>
      </div>
    </div>
  );
}

// Timer details components
function Timer0Details() {
  return (
    <div className="space-y-6">
      <div className="bg-orange-50 p-6 rounded-lg border-2 border-orange-300">
        <h3 className="text-xl font-bold text-orange-900 mb-3">⏱️ Critical Arduino Functions</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-white p-4 rounded">
            <p className="font-mono font-bold text-orange-800 mb-2">millis()</p>
            <p className="text-sm text-orange-700">
              Returns milliseconds since program start. Overflows after ~49 days. 
              Updated by Timer0 overflow interrupt every 1.024ms.
            </p>
          </div>
          <div className="bg-white p-4 rounded">
            <p className="font-mono font-bold text-orange-800 mb-2">delay()</p>
            <p className="text-sm text-orange-700">
              Blocks execution using millis(). DON'T use in time-critical code. 
              Consider non-blocking alternatives.
            </p>
          </div>
        </div>
      </div>

      <div className="bg-blue-50 p-6 rounded-lg border-2 border-blue-300">
        <h3 className="text-xl font-bold text-blue-900 mb-3">🎛️ Registers</h3>
        <div className="space-y-2 font-mono text-sm">
          <div className="bg-white p-3 rounded flex justify-between">
            <span className="font-bold text-blue-700">TCCR0A</span>
            <span className="text-blue-600">Timer/Counter Control Register A (Waveform mode)</span>
          </div>
          <div className="bg-white p-3 rounded flex justify-between">
            <span className="font-bold text-blue-700">TCCR0B</span>
            <span className="text-blue-600">Timer/Counter Control Register B (Clock select)</span>
          </div>
          <div className="bg-white p-3 rounded flex justify-between">
            <span className="font-bold text-blue-700">TCNT0</span>
            <span className="text-blue-600">Timer/Counter Register (0-255)</span>
          </div>
          <div className="bg-white p-3 rounded flex justify-between">
            <span className="font-bold text-blue-700">OCR0A</span>
            <span className="text-blue-600">Output Compare Register A (PWM D6)</span>
          </div>
          <div className="bg-white p-3 rounded flex justify-between">
            <span className="font-bold text-blue-700">OCR0B</span>
            <span className="text-blue-600">Output Compare Register B (PWM D5)</span>
          </div>
        </div>
      </div>

      <div className="bg-green-50 p-6 rounded-lg border-2 border-green-300">
        <h3 className="text-xl font-bold text-green-900 mb-3">🌊 PWM Output</h3>
        <p className="text-sm text-green-800 mb-3">
          Pins 5 (OC0B) and 6 (OC0A) can output PWM signals controlled by Timer0.
        </p>
        <div className="bg-white p-4 rounded font-mono text-sm">
          <div className="text-gray-600">// Set PWM on pin 6</div>
          <div className="text-green-700">analogWrite(6, 128); // 50% duty cycle</div>
          <div className="text-gray-600 mt-2">// Frequency: ~980 Hz (Fast PWM)</div>
        </div>
      </div>

      <div className="bg-red-50 p-4 rounded-lg border border-red-300">
        <p className="text-sm text-red-800">
          <strong>⚠️ Warning:</strong> Modifying Timer0 registers will break millis(), delay(), and micros(). 
          Only do this if you know what you're doing and don't need those functions!
        </p>
      </div>
    </div>
  );
}

function Timer1Details() {
  return (
    <div className="space-y-6">
      <div className="bg-purple-50 p-6 rounded-lg border-2 border-purple-300">
        <h3 className="text-xl font-bold text-purple-900 mb-3">🎯 16-bit Precision</h3>
        <p className="text-sm text-purple-800 mb-4">
          Timer1 is a 16-bit timer, giving much finer control than 8-bit timers. 
          Count range: 0 to 65,535 instead of 0-255.
        </p>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-white p-4 rounded">
            <p className="font-semibold text-purple-800 mb-2">Use Cases:</p>
            <ul className="text-sm text-purple-700 space-y-1">
              <li>• Precise timing intervals</li>
              <li>• Servo motor control (Servo.h)</li>
              <li>• High-resolution PWM</li>
              <li>• Frequency measurement</li>
              <li>• Input capture (measure pulse width)</li>
            </ul>
          </div>
          <div className="bg-white p-4 rounded">
            <p className="font-semibold text-purple-800 mb-2">PWM Outputs:</p>
            <ul className="text-sm text-purple-700 space-y-1">
              <li>• Pin 9: OC1A (OCR1A)</li>
              <li>• Pin 10: OC1B (OCR1B)</li>
              <li>• Frequency: ~490 Hz default</li>
              <li>• Can go much higher/lower</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="bg-blue-50 p-6 rounded-lg border-2 border-blue-300">
        <h3 className="text-xl font-bold text-blue-900 mb-3">📋 Key Registers</h3>
        <div className="space-y-2 font-mono text-sm">
          <div className="bg-white p-3 rounded">
            <span className="font-bold text-blue-700">TCNT1</span>
            <span className="text-blue-600 ml-4">16-bit counter (TCNT1H:TCNT1L)</span>
          </div>
          <div className="bg-white p-3 rounded">
            <span className="font-bold text-blue-700">OCR1A</span>
            <span className="text-blue-600 ml-4">Output Compare A (controls pin 9)</span>
          </div>
          <div className="bg-white p-3 rounded">
            <span className="font-bold text-blue-700">OCR1B</span>
            <span className="text-blue-600 ml-4">Output Compare B (controls pin 10)</span>
          </div>
          <div className="bg-white p-3 rounded">
            <span className="font-bold text-blue-700">ICR1</span>
            <span className="text-blue-600 ml-4">Input Capture Register (TOP value in some modes)</span>
          </div>
        </div>
      </div>

      <div className="bg-green-50 p-6 rounded-lg border-2 border-green-300">
        <h3 className="text-xl font-bold text-green-900 mb-3">🤖 Servo Library Example</h3>
        <div className="bg-gray-800 text-green-400 p-4 rounded font-mono text-sm space-y-2">
          <div className="text-gray-400">// Servo library uses Timer1</div>
          <div>#include &lt;Servo.h&gt;</div>
          <div>Servo myServo;</div>
          <div className="mt-2">void setup() {'{'}</div>
          <div className="ml-4">myServo.attach(9); // Pin 9</div>
          <div>{'}'}</div>
          <div className="mt-2">void loop() {'{'}</div>
          <div className="ml-4">myServo.write(90); // 90 degrees</div>
          <div className="ml-4">delay(1000);</div>
          <div>{'}'}</div>
        </div>
        <p className="text-xs text-green-700 mt-3">
          Note: Timer1 generates precise 1-2ms pulses for servo control (50Hz PWM)
        </p>
      </div>
    </div>
  );
}

function Timer2Details() {
  return (
    <div className="space-y-6">
      <div className="bg-indigo-50 p-6 rounded-lg border-2 border-indigo-300">
        <h3 className="text-xl font-bold text-indigo-900 mb-3">🔊 Audio Applications</h3>
        <p className="text-sm text-indigo-800 mb-4">
          Timer2 is commonly used by the tone() function to generate square wave audio frequencies on any digital pin.
        </p>
        <div className="bg-gray-800 text-green-400 p-4 rounded font-mono text-sm space-y-2">
          <div className="text-gray-400">// Generate 1kHz tone on pin 8</div>
          <div>tone(8, 1000); // frequency in Hz</div>
          <div>delay(500);</div>
          <div>noTone(8); // stop the tone</div>
        </div>
      </div>

      <div className="bg-yellow-50 p-6 rounded-lg border-2 border-yellow-300">
        <h3 className="text-xl font-bold text-yellow-900 mb-3">🎛️ PWM Outputs</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-white p-4 rounded">
            <p className="font-bold text-yellow-800 mb-2">Pin 11 (OC2A)</p>
            <p className="text-sm text-yellow-700">Controlled by OCR2A register. Default PWM frequency: ~490 Hz</p>
          </div>
          <div className="bg-white p-4 rounded">
            <p className="font-bold text-yellow-800 mb-2">Pin 3 (OC2B)</p>
            <p className="text-sm text-yellow-700">Controlled by OCR2B register. Used by analogWrite(3, value)</p>
          </div>
        </div>
      </div>

      <div className="bg-blue-50 p-6 rounded-lg border-2 border-blue-300">
        <h3 className="text-xl font-bold text-blue-900 mb-3">📊 Registers</h3>
        <div className="space-y-2 font-mono text-sm">
          <div className="bg-white p-3 rounded">
            <span className="font-bold text-blue-700">TCCR2A/B</span>
            <span className="text-blue-600 ml-4">Control registers (mode and prescaler)</span>
          </div>
          <div className="bg-white p-3 rounded">
            <span className="font-bold text-blue-700">TCNT2</span>
            <span className="text-blue-600 ml-4">8-bit counter (0-255)</span>
          </div>
          <div className="bg-white p-3 rounded">
            <span className="font-bold text-blue-700">OCR2A/B</span>
            <span className="text-blue-600 ml-4">Output compare registers for PWM</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function USARTDetails() {
  return (
    <div className="space-y-6">
      <div className="bg-blue-50 p-6 rounded-lg border-2 border-blue-300">
        <h3 className="text-xl font-bold text-blue-900 mb-3">📡 Serial Communication</h3>
        <p className="text-sm text-blue-800 mb-4">
          USART (Universal Synchronous/Asynchronous Receiver/Transmitter) enables communication between Arduino 
          and computers, other Arduinos, or serial devices.
        </p>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <p className="font-semibold text-blue-800 mb-2">Pins:</p>
            <ul className="text-sm text-blue-700 space-y-1">
              <li>• Pin 0 (RX): Receive data</li>
              <li>• Pin 1 (TX): Transmit data</li>
              <li>• Shared with USB programmer</li>
            </ul>
          </div>
          <div>
            <p className="font-semibold text-blue-800 mb-2">Common Baud Rates:</p>
            <ul className="text-sm text-blue-700 space-y-1 font-mono">
              <li>• 9600 (default)</li>
              <li>• 19200</li>
              <li>• 57600</li>
              <li>• 115200 (max reliable)</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="bg-green-50 p-6 rounded-lg border-2 border-green-300">
        <h3 className="text-xl font-bold text-green-900 mb-3">💻 Arduino Usage</h3>
        <div className="bg-gray-800 text-green-400 p-4 rounded font-mono text-sm space-y-2">
          <div className="text-gray-400">// Initialize serial</div>
          <div>Serial.begin(9600);</div>
          <div className="mt-2 text-gray-400">// Send data</div>
          <div>Serial.println("Hello World");</div>
          <div>Serial.print(sensorValue);</div>
          <div className="mt-2 text-gray-400">// Receive data</div>
          <div>if (Serial.available()) {'{'}</div>
          <div className="ml-4">char c = Serial.read();</div>
          <div>{'}'}</div>
        </div>
      </div>

      <div className="bg-purple-50 p-6 rounded-lg border-2 border-purple-300">
        <h3 className="text-xl font-bold text-purple-900 mb-3">⚙️ Baud Rate Calculation</h3>
        <div className="bg-white p-4 rounded">
          <p className="font-mono text-purple-800 mb-2">UBRR = (f_CPU / (16 × BAUD)) - 1</p>
          <p className="text-sm text-purple-700 mb-3">For 16MHz crystal at 9600 baud:</p>
          <p className="font-mono text-sm text-purple-800">UBRR = (16,000,000 / (16 × 9600)) - 1 = 103</p>
          <p className="text-xs text-purple-600 mt-2">Arduino IDE handles this automatically!</p>
        </div>
      </div>

      <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-300">
        <p className="text-sm text-yellow-800">
          <strong>💡 Tip:</strong> The USART has a 2-byte hardware buffer. For larger data, implement your own 
          buffer or use interrupts to avoid data loss.
        </p>
      </div>
    </div>
  );
}

function SPIDetails() {
  return (
    <div className="space-y-6">
      <div className="bg-orange-50 p-6 rounded-lg border-2 border-orange-300">
        <h3 className="text-xl font-bold text-orange-900 mb-3">⚡ High-Speed Serial</h3>
        <p className="text-sm text-orange-800 mb-4">
          SPI (Serial Peripheral Interface) is a synchronous protocol for fast communication with peripherals 
          like SD cards, displays, sensors, and more.
        </p>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-white p-4 rounded">
            <p className="font-bold text-orange-800 mb-2">Pins:</p>
            <ul className="text-sm text-orange-700 space-y-1">
              <li>• MOSI (D11): Master Out Slave In</li>
              <li>• MISO (D12): Master In Slave Out</li>
              <li>• SCK (D13): Serial Clock</li>
              <li>• SS (D10): Slave Select</li>
            </ul>
          </div>
          <div className="bg-white p-4 rounded">
            <p className="font-bold text-orange-800 mb-2">Features:</p>
            <ul className="text-sm text-orange-700 space-y-1">
              <li>• Full-duplex communication</li>
              <li>• Up to 8 MHz clock speed</li>
              <li>• Master/Slave modes</li>
              <li>• No addressing (SS pins)</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="bg-blue-50 p-6 rounded-lg border-2 border-blue-300">
        <h3 className="text-xl font-bold text-blue-900 mb-3">💻 Arduino Usage</h3>
        <div className="bg-gray-800 text-green-400 p-4 rounded font-mono text-sm space-y-2">
          <div className="text-gray-400">// Include SPI library</div>
          <div>#include &lt;SPI.h&gt;</div>
          <div className="mt-2">void setup() {'{'}</div>
          <div className="ml-4">SPI.begin();</div>
          <div className="ml-4">SPI.setClockDivider(SPI_CLOCK_DIV4);</div>
          <div>{'}'}</div>
          <div className="mt-2 text-gray-400">// Transfer data</div>
          <div>digitalWrite(SS, LOW);</div>
          <div>byte response = SPI.transfer(0x42);</div>
          <div>digitalWrite(SS, HIGH);</div>
        </div>
      </div>

      <div className="bg-green-50 p-6 rounded-lg border-2 border-green-300">
        <h3 className="text-xl font-bold text-green-900 mb-3">🔌 Common SPI Devices</h3>
        <div className="grid md:grid-cols-3 gap-4">
          <div className="bg-white p-3 rounded text-sm">
            <p className="font-bold text-green-800">💾 SD Cards</p>
            <p className="text-green-700">File storage</p>
          </div>
          <div className="bg-white p-3 rounded text-sm">
            <p className="font-bold text-green-800">🖥️ TFT Displays</p>
            <p className="text-green-700">Fast graphics</p>
          </div>
          <div className="bg-white p-3 rounded text-sm">
            <p className="font-bold text-green-800">📡 NRF24L01</p>
            <p className="text-green-700">Wireless modules</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function I2CDetails() {
  return (
    <div className="space-y-6">
      <div className="bg-cyan-50 p-6 rounded-lg border-2 border-cyan-300">
        <h3 className="text-xl font-bold text-cyan-900 mb-3">🔗 Two-Wire Bus</h3>
        <p className="text-sm text-cyan-800 mb-4">
          I2C (Inter-Integrated Circuit) / TWI (Two-Wire Interface) connects multiple devices using just 2 wires.
        </p>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-white p-4 rounded">
            <p className="font-bold text-cyan-800 mb-2">Pins:</p>
            <ul className="text-sm text-cyan-700 space-y-1">
              <li>• SDA (A4): Serial Data</li>
              <li>• SCL (A5): Serial Clock</li>
              <li>• Both need pull-up resistors</li>
            </ul>
          </div>
          <div className="bg-white p-4 rounded">
            <p className="font-bold text-cyan-800 mb-2">Addressing:</p>
            <ul className="text-sm text-cyan-700 space-y-1">
              <li>• 7-bit addresses (0x00-0x7F)</li>
              <li>• Up to 127 devices per bus</li>
              <li>• Each device has unique address</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="bg-blue-50 p-6 rounded-lg border-2 border-blue-300">
        <h3 className="text-xl font-bold text-blue-900 mb-3">💻 Arduino Wire Library</h3>
        <div className="bg-gray-800 text-green-400 p-4 rounded font-mono text-sm space-y-2">
          <div className="text-gray-400">// Include Wire library</div>
          <div>#include &lt;Wire.h&gt;</div>
          <div className="mt-2">void setup() {'{'}</div>
          <div className="ml-4">Wire.begin(); // Join as master</div>
          <div>{'}'}</div>
          <div className="mt-2 text-gray-400">// Write to device at 0x50</div>
          <div>Wire.beginTransmission(0x50);</div>
          <div>Wire.write(0x00); // register</div>
          <div>Wire.write(0xFF); // value</div>
          <div>Wire.endTransmission();</div>
          <div className="mt-2 text-gray-400">// Read from device</div>
          <div>Wire.requestFrom(0x50, 1);</div>
          <div>if (Wire.available()) {'{'}</div>
          <div className="ml-4">byte data = Wire.read();</div>
          <div>{'}'}</div>
        </div>
      </div>

      <div className="bg-purple-50 p-6 rounded-lg border-2 border-purple-300">
        <h3 className="text-xl font-bold text-purple-900 mb-3">🔌 Popular I2C Devices</h3>
        <div className="grid md:grid-cols-4 gap-3 text-sm">
          <div className="bg-white p-3 rounded">
            <p className="font-bold text-purple-800">🌡️ BMP280</p>
            <p className="text-purple-700 text-xs">Temp/Pressure</p>
          </div>
          <div className="bg-white p-3 rounded">
            <p className="font-bold text-purple-800">⏰ DS3231</p>
            <p className="text-purple-700 text-xs">RTC Clock</p>
          </div>
          <div className="bg-white p-3 rounded">
            <p className="font-bold text-purple-800">🖥️ OLED</p>
            <p className="text-purple-700 text-xs">Displays</p>
          </div>
          <div className="bg-white p-3 rounded">
            <p className="font-bold text-purple-800">🧭 MPU6050</p>
            <p className="text-purple-700 text-xs">IMU Sensor</p>
          </div>
        </div>
      </div>

      <div className="bg-green-50 p-4 rounded-lg border border-green-300">
        <p className="text-sm text-green-800">
          <strong>💡 Tip:</strong> Use an I2C scanner sketch to find device addresses. Most I2C modules include 
          pull-up resistors, but you may need to add 4.7kΩ resistors if you have issues.
        </p>
      </div>
    </div>
  );
}

function ADCDetails() {
  return (
    <div className="space-y-6">
      <div className="bg-violet-50 p-6 rounded-lg border-2 border-violet-300">
        <h3 className="text-xl font-bold text-violet-900 mb-3">📊 10-bit Resolution</h3>
        <p className="text-sm text-violet-800 mb-4">
          Converts analog voltages (0-5V) to digital values (0-1023). Six channels available on pins A0-A5.
        </p>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-white p-4 rounded">
            <p className="font-bold text-violet-800 mb-2">Resolution:</p>
            <p className="text-sm text-violet-700 font-mono">5V / 1024 = 4.88mV per step</p>
            <p className="text-xs text-violet-600 mt-2">Each count represents ~4.88 millivolts</p>
          </div>
          <div className="bg-white p-4 rounded">
            <p className="font-bold text-violet-800 mb-2">Conversion Time:</p>
            <p className="text-sm text-violet-700">~104µs @ 16MHz</p>
            <p className="text-xs text-violet-600 mt-1">(13 ADC clock cycles × 8µs)</p>
            <p className="text-xs text-violet-600">Max ~9600 samples/second</p>
          </div>
        </div>
      </div>

      <div className="bg-green-50 p-6 rounded-lg border-2 border-green-300">
        <h3 className="text-xl font-bold text-green-900 mb-3">💻 Arduino Usage</h3>
        <div className="bg-gray-800 text-green-400 p-4 rounded font-mono text-sm space-y-2">
          <div className="text-gray-400">// Read analog value (0-1023)</div>
          <div>int sensorValue = analogRead(A0);</div>
          <div className="mt-2 text-gray-400">// Convert to voltage</div>
          <div>float voltage = sensorValue * (5.0 / 1023.0);</div>
          <div className="mt-2 text-gray-400">// Map to range</div>
          <div>int percent = map(sensorValue, 0, 1023, 0, 100);</div>
        </div>
      </div>

      <div className="bg-blue-50 p-6 rounded-lg border-2 border-blue-300">
        <h3 className="text-xl font-bold text-blue-900 mb-3">🎯 Reference Voltage</h3>
        <div className="space-y-3">
          <div className="bg-white p-3 rounded">
            <p className="font-bold text-blue-800">DEFAULT (5V)</p>
            <p className="text-sm text-blue-700">Uses VCC as reference (default)</p>
          </div>
          <div className="bg-white p-3 rounded">
            <p className="font-bold text-blue-800">INTERNAL (1.1V)</p>
            <p className="text-sm text-blue-700">Better resolution for low voltages: 1.1V / 1024 = 1.07mV/step</p>
          </div>
          <div className="bg-white p-3 rounded">
            <p className="font-bold text-blue-800">EXTERNAL (AREF pin)</p>
            <p className="text-sm text-blue-700">Use custom reference voltage on AREF pin</p>
          </div>
        </div>
        <div className="bg-gray-800 text-green-400 p-3 rounded font-mono text-sm mt-3">
          <div>analogReference(INTERNAL); // Use 1.1V</div>
        </div>
      </div>

      <div className="bg-yellow-50 p-6 rounded-lg border-2 border-yellow-300">
        <h3 className="text-xl font-bold text-yellow-900 mb-3">⚡ Performance Tips</h3>
        <ul className="space-y-2 text-sm text-yellow-800">
          <li>• First reading after analogRead() may be inaccurate - discard it</li>
          <li>• Add small capacitor (0.1µF) to analog inputs to reduce noise</li>
          <li>• Keep analog wires short and away from digital signals</li>
          <li>• Average multiple readings for stability</li>
          <li>• Use AVCC pin for cleaner analog supply</li>
        </ul>
      </div>

      <div className="bg-purple-50 p-4 rounded-lg border border-purple-300">
        <p className="text-sm text-purple-800">
          <strong>💡 Example:</strong> Reading a 10kΩ potentiometer on A0 gives 0-1023. 
          At 512, the potentiometer is at 50% (2.5V). Use map() to convert to desired range.
        </p>
      </div>
    </div>
  );
}

function WatchdogDetails() {
  return (
    <div className="space-y-6">
      <div className="bg-red-50 p-6 rounded-lg border-2 border-red-300">
        <h3 className="text-xl font-bold text-red-900 mb-3">🐕 System Guardian</h3>
        <p className="text-sm text-red-800 mb-4">
          The Watchdog Timer (WDT) acts as a failsafe, resetting the microcontroller if software hangs or crashes.
        </p>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-white p-4 rounded">
            <p className="font-bold text-red-800 mb-2">How it works:</p>
            <ol className="text-sm text-red-700 space-y-1">
              <li>1. Set timeout period (15ms - 8s)</li>
              <li>2. Watchdog starts counting</li>
              <li>3. Software must "pet the dog" (reset timer)</li>
              <li>4. If timeout expires → system reset</li>
            </ol>
          </div>
          <div className="bg-white p-4 rounded">
            <p className="font-bold text-red-800 mb-2">Timeout Options:</p>
            <ul className="text-sm text-red-700 space-y-1 font-mono">
              <li>• 15ms</li>
              <li>• 30ms, 60ms, 120ms</li>
              <li>• 250ms, 500ms</li>
              <li>• 1s, 2s, 4s, 8s</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="bg-blue-50 p-6 rounded-lg border-2 border-blue-300">
        <h3 className="text-xl font-bold text-blue-900 mb-3">💻 Arduino Usage</h3>
        <div className="bg-gray-800 text-green-400 p-4 rounded font-mono text-sm space-y-2">
          <div className="text-gray-400">// Include library</div>
          <div>#include &lt;avr/wdt.h&gt;</div>
          <div className="mt-2">void setup() {'{'}</div>
          <div className="ml-4 text-gray-400">// Enable 2-second timeout</div>
          <div className="ml-4">wdt_enable(WDTO_2S);</div>
          <div>{'}'}</div>
          <div className="mt-2">void loop() {'{'}</div>
          <div className="ml-4 text-gray-400">// Reset watchdog (pet the dog)</div>
          <div className="ml-4">wdt_reset();</div>
          <div className="ml-4"></div>
          <div className="ml-4 text-gray-400">// Your code here...</div>
          <div className="ml-4"></div>
          <div className="ml-4 text-gray-400">// Must call wdt_reset() before 2s!</div>
          <div>{'}'}</div>
        </div>
      </div>

      <div className="bg-yellow-50 p-6 rounded-lg border-2 border-yellow-300">
        <h3 className="text-xl font-bold text-yellow-900 mb-3">⚠️ Important Notes</h3>
        <ul className="space-y-2 text-sm text-yellow-800">
          <li>• <strong>Bootloader issues:</strong> Some bootloaders don't disable WDT, causing boot loops</li>
          <li>• Always call <code className="bg-yellow-100 px-1">wdt_disable()</code> in setup() first</li>
          <li>• Don't use with delay() longer than timeout period</li>
          <li>• Can cause unexpected resets if not managed properly</li>
          <li>• Use for production systems prone to crashes</li>
        </ul>
      </div>

      <div className="bg-green-50 p-6 rounded-lg border-2 border-green-300">
        <h3 className="text-xl font-bold text-green-900 mb-3">✅ Use Cases</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-white p-4 rounded">
            <p className="font-semibold text-green-800 mb-2">Reliable Systems:</p>
            <p className="text-sm text-green-700">
              Remote sensors, IoT devices, automation - anything that needs to recover from crashes without human intervention.
            </p>
          </div>
          <div className="bg-white p-4 rounded">
            <p className="font-semibold text-green-800 mb-2">Sleep Mode Wake:</p>
            <p className="text-sm text-green-700">
              WDT can also generate interrupts to wake Arduino from deep sleep at regular intervals.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function GPIODetails({ port }: { port: string }) {
  return (
    <div className="space-y-6">
      <div className="bg-slate-50 p-6 rounded-lg border-2 border-slate-300">
        <h3 className="text-xl font-bold text-slate-900 mb-3">📌 Port {port} Configuration</h3>
        <p className="text-sm text-slate-700 mb-4">
          Each GPIO port has three registers to control its behavior:
        </p>
        <div className="grid md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded border-2 border-blue-300">
            <p className="font-mono font-bold text-blue-800 mb-2">PIN{port}</p>
            <p className="text-sm text-blue-700">Read pin states</p>
            <p className="text-xs text-blue-600 mt-1">Input register</p>
          </div>
          <div className="bg-white p-4 rounded border-2 border-green-300">
            <p className="font-mono font-bold text-green-800 mb-2">DDR{port}</p>
            <p className="text-sm text-green-700">Set pin direction</p>
            <p className="text-xs text-green-600 mt-1">0=Input, 1=Output</p>
          </div>
          <div className="bg-white p-4 rounded border-2 border-purple-300">
            <p className="font-mono font-bold text-purple-800 mb-2">PORT{port}</p>
            <p className="text-sm text-purple-700">Write pin states</p>
            <p className="text-xs text-purple-600 mt-1">Output register</p>
          </div>
        </div>
      </div>

      <div className="bg-blue-50 p-6 rounded-lg border-2 border-blue-300">
        <h3 className="text-xl font-bold text-blue-900 mb-3">💻 Direct Port Manipulation</h3>
        <div className="bg-gray-800 text-green-400 p-4 rounded font-mono text-sm space-y-2">
          <div className="text-gray-400">// Set P{port}5 as output</div>
          <div>DDR{port} |= (1 &lt;&lt; 5);</div>
          <div className="mt-2 text-gray-400">// Set P{port}5 HIGH</div>
          <div>PORT{port} |= (1 &lt;&lt; 5);</div>
          <div className="mt-2 text-gray-400">// Set P{port}5 LOW</div>
          <div>PORT{port} &= ~(1 &lt;&lt; 5);</div>
          <div className="mt-2 text-gray-400">// Read P{port}3 state</div>
          <div>if (PIN{port} & (1 &lt;&lt; 3)) {'{'}</div>
          <div className="ml-4 text-gray-400">// Pin is HIGH</div>
          <div>{'}'}</div>
        </div>
        <p className="text-xs text-blue-700 mt-3">
          ⚡ Direct port access is much faster than digitalWrite() - useful for time-critical operations!
        </p>
      </div>

      <div className="bg-green-50 p-6 rounded-lg border-2 border-green-300">
        <h3 className="text-xl font-bold text-green-900 mb-3">🎯 Special Functions</h3>
        {port === 'B' && (
          <ul className="space-y-2 text-sm text-green-800">
            <li>• <strong>PB0-PB5:</strong> Arduino pins D8-D13</li>
            <li>• <strong>PB5:</strong> Built-in LED (LED_BUILTIN)</li>
            <li>• <strong>PB2-PB5:</strong> SPI interface (SS, MOSI, MISO, SCK)</li>
            <li>• <strong>PB6-PB7:</strong> Crystal oscillator (XTAL1, XTAL2)</li>
          </ul>
        )}
        {port === 'C' && (
          <ul className="space-y-2 text-sm text-green-800">
            <li>• <strong>PC0-PC5:</strong> Arduino pins A0-A5 (analog inputs)</li>
            <li>• <strong>PC4:</strong> SDA (I2C data line)</li>
            <li>• <strong>PC5:</strong> SCL (I2C clock line)</li>
            <li>• <strong>PC6:</strong> RESET pin (with fuse programming)</li>
            <li>• Can be used as digital I/O when not reading ADC</li>
          </ul>
        )}
        {port === 'D' && (
          <ul className="space-y-2 text-sm text-green-800">
            <li>• <strong>PD0-PD7:</strong> Arduino pins D0-D7</li>
            <li>• <strong>PD0:</strong> RX (USART receive)</li>
            <li>• <strong>PD1:</strong> TX (USART transmit)</li>
            <li>• <strong>PD2:</strong> INT0 (external interrupt 0)</li>
            <li>• <strong>PD3:</strong> INT1 (external interrupt 1)</li>
            <li>• <strong>PD3, PD5, PD6:</strong> PWM outputs (Timer 2, Timer 0)</li>
          </ul>
        )}
      </div>

      <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-300">
        <p className="text-sm text-yellow-800">
          <strong>💡 Performance:</strong> Using port manipulation (PORTB |= 0x20) is ~40x faster than digitalWrite(13, HIGH) 
          because it avoids function call overhead and pin number translation.
        </p>
      </div>
    </div>
  );
}

function CPUCoreDetails() {
  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-br from-blue-900 to-indigo-900 p-6 rounded-xl border-2 border-blue-500">
        <h3 className="text-2xl font-bold text-blue-300 mb-4">🎛️ Interactive CPU Core Simulators</h3>
        <p className="text-blue-200 mb-4">
          Explore each component of the CPU core with interactive demonstrations!
        </p>
      </div>
      
      <InteractiveInstructionFetch />
      <InteractiveDecoder />
      <InteractiveControlUnit />
      <InteractiveALU />
    </div>
  );
}

function InterruptDetails() {
  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-br from-indigo-900 to-indigo-800 p-6 rounded-lg border-2 border-indigo-500">
        <h3 className="text-xl font-bold text-indigo-900 mb-3">⚡ Event-Driven Programming</h3>
        <p className="text-sm text-indigo-800 mb-4">
          Interrupts allow the CPU to respond immediately to hardware events without polling, 
          making your code more responsive and efficient.
        </p>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-white p-4 rounded">
            <p className="font-bold text-indigo-800 mb-2">How Interrupts Work:</p>
            <ol className="text-sm text-indigo-700 space-y-1">
              <li>1. Event occurs (pin change, timer overflow, etc.)</li>
              <li>2. Current instruction finishes</li>
              <li>3. Program counter saved to stack</li>
              <li>4. Jump to interrupt vector</li>
              <li>5. Execute ISR (Interrupt Service Routine)</li>
              <li>6. RETI: restore PC and continue main code</li>
            </ol>
          </div>
          <div className="bg-white p-4 rounded">
            <p className="font-bold text-indigo-800 mb-2">Characteristics:</p>
            <ul className="text-sm text-indigo-700 space-y-1">
              <li>• <strong>Latency:</strong> 4 clock cycles</li>
              <li>• <strong>Nested:</strong> Disabled during ISR</li>
              <li>• <strong>Priority:</strong> Lower address = higher priority</li>
              <li>• <strong>Global flag:</strong> SREG bit I</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="bg-blue-50 p-6 rounded-lg border-2 border-blue-300">
        <h3 className="text-xl font-bold text-blue-900 mb-3">📋 Interrupt Vector Table</h3>
        <div className="bg-white p-4 rounded font-mono text-xs space-y-1 max-h-60 overflow-y-auto">
          <div className="grid grid-cols-3 gap-2 font-bold text-blue-800 sticky top-0 bg-white pb-2">
            <div>Address</div>
            <div>Source</div>
            <div>Description</div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <div className="text-blue-600">0x0000</div>
            <div className="text-blue-700">RESET</div>
            <div className="text-blue-600">External Pin, Power-on, WDT</div>
          </div>
          <div className="grid grid-cols-3 gap-2 bg-yellow-50">
            <div className="text-blue-600">0x0002</div>
            <div className="text-blue-700">INT0</div>
            <div className="text-blue-600">External Interrupt 0</div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <div className="text-blue-600">0x0004</div>
            <div className="text-blue-700">INT1</div>
            <div className="text-blue-600">External Interrupt 1</div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <div className="text-blue-600">0x0006</div>
            <div className="text-blue-700">PCINT0</div>
            <div className="text-blue-600">Pin Change Interrupt 0 (Port B)</div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <div className="text-blue-600">0x0008</div>
            <div className="text-blue-700">PCINT1</div>
            <div className="text-blue-600">Pin Change Interrupt 1 (Port C)</div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <div className="text-blue-600">0x000A</div>
            <div className="text-blue-700">PCINT2</div>
            <div className="text-blue-600">Pin Change Interrupt 2 (Port D)</div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <div className="text-blue-600">0x000C</div>
            <div className="text-blue-700">WDT</div>
            <div className="text-blue-600">Watchdog Time-out</div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <div className="text-blue-600">0x0012</div>
            <div className="text-blue-700">TIMER1_OVF</div>
            <div className="text-blue-600">Timer1 Overflow</div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <div className="text-blue-600">0x001C</div>
            <div className="text-blue-700">TIMER0_OVF</div>
            <div className="text-blue-600">Timer0 Overflow</div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <div className="text-blue-600">0x0024</div>
            <div className="text-blue-700">USART_RX</div>
            <div className="text-blue-600">USART Rx Complete</div>
          </div>
          <div className="text-gray-500 text-center py-2">... 26 total interrupt sources ...</div>
        </div>
      </div>

      <div className="bg-green-50 p-6 rounded-lg border-2 border-green-300">
        <h3 className="text-xl font-bold text-green-900 mb-3">💻 Arduino External Interrupts</h3>
        <div className="bg-gray-800 text-green-400 p-4 rounded font-mono text-sm space-y-2">
          <div className="text-gray-400">// Attach interrupt to pin 2 (INT0)</div>
          <div>void setup() {'{'}</div>
          <div className="ml-4">pinMode(2, INPUT_PULLUP);</div>
          <div className="ml-4">attachInterrupt(digitalPinToInterrupt(2),</div>
          <div className="ml-20">myISR, FALLING);</div>
          <div>{'}'}</div>
          <div className="mt-2 text-gray-400">// Interrupt Service Routine</div>
          <div>void myISR() {'{'}</div>
          <div className="ml-4 text-gray-400">// Keep this short and fast!</div>
          <div className="ml-4">digitalWrite(13, !digitalRead(13));</div>
          <div>{'}'}</div>
        </div>
      </div>

      <div className="bg-red-50 p-6 rounded-lg border-2 border-red-300">
        <h3 className="text-xl font-bold text-red-900 mb-3">⚠️ ISR Best Practices</h3>
        <ul className="space-y-2 text-sm text-red-800">
          <li>• ❌ <strong>Never use delay()</strong> in ISR - timers are disabled</li>
          <li>• ❌ <strong>Don't use Serial.print()</strong> - too slow</li>
          <li>• ✅ Keep ISR short - set flags, save data, exit quickly</li>
          <li>• ✅ Use <code className="bg-red-100 px-1">volatile</code> for variables shared between ISR and main code</li>
          <li>• ✅ Disable interrupts if accessing multi-byte variables: <code className="bg-red-100 px-1">noInterrupts(); ... interrupts();</code></li>
          <li>• ⚡ ISR should complete in microseconds, not milliseconds</li>
        </ul>
      </div>

      <div className="bg-purple-50 p-4 rounded-lg border border-purple-300">
        <p className="text-sm text-purple-800">
          <strong>💡 Tip:</strong> Pin 2 and 3 support external interrupts (INT0, INT1). All pins support pin change interrupts (PCINT), 
          but they're grouped by port and require more complex handling.
        </p>
      </div>
    </div>
  );
}
