export default function ClockPower() {
  return (
    <g id="clock-power">
      <rect x="50" y="20" width="1400" height="80" fill="#1E293B" stroke="#475569" strokeWidth="2" rx="6"/>
      <text x="60" y="40" className="font-bold text-sm fill-slate-300">CLOCK & POWER</text>
      
      {/* Crystal */}
      <rect x="80" y="50" width="110" height="35" fill="#422006" stroke="#F59E0B" strokeWidth="2" rx="4"/>
      <text x="88" y="68" className="text-xs font-semibold fill-amber-300">16MHz Crystal</text>
      <text x="92" y="80" className="text-xs fill-amber-400">XTAL1/XTAL2</text>
      
      {/* Clock Distribution */}
      <line x1="190" y1="67" x2="230" y2="67" stroke="#94A3B8" strokeWidth="2"/>
      <circle cx="230" cy="67" r="3" fill="#94A3B8"/>
      
      {/* Branches */}
      <line x1="230" y1="67" x2="270" y2="52" stroke="#94A3B8" strokeWidth="1.5" markerEnd="url(#arrowGray)"/>
      <text x="275" y="52" className="text-xs fill-slate-400">CPU</text>
      
      <line x1="230" y1="67" x2="270" y2="67" stroke="#94A3B8" strokeWidth="1.5" markerEnd="url(#arrowGray)"/>
      <text x="275" y="70" className="text-xs fill-slate-400">Timers</text>
      
      <line x1="230" y1="67" x2="270" y2="82" stroke="#94A3B8" strokeWidth="1.5" markerEnd="url(#arrowGray)"/>
      <text x="275" y="85" className="text-xs fill-slate-400">USART/SPI</text>
      
      {/* ADC Prescaler */}
      <line x1="230" y1="67" x2="400" y2="67" stroke="#94A3B8" strokeWidth="1.5"/>
      <rect x="410" y="57" width="50" height="20" fill="#1E3A8A" stroke="#3B82F6" strokeWidth="1.5" rx="3"/>
      <text x="420" y="70" className="text-xs font-semibold fill-blue-300">÷128</text>
      <line x1="460" y1="67" x2="510" y2="67" stroke="#94A3B8" strokeWidth="1.5" markerEnd="url(#arrowGray)"/>
      <text x="515" y="70" className="text-xs fill-slate-400">ADC 125kHz</text>
      
      {/* Power */}
      <rect x="750" y="50" width="250" height="35" fill="#14532D" stroke="#22C55E" strokeWidth="2" rx="4"/>
      <text x="760" y="65" className="text-xs font-bold fill-green-300">VCC 5V</text>
      <text x="820" y="65" className="text-xs font-bold fill-green-300">GND</text>
      <text x="870" y="65" className="text-xs font-bold fill-green-300">AVCC</text>
      <text x="920" y="65" className="text-xs font-bold fill-green-300">AREF</text>
      <text x="760" y="78" className="text-xs fill-green-400">Analog supply</text>
    </g>
  );
}
