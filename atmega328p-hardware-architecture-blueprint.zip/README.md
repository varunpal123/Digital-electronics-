# ATmega328P Interactive Architecture Blueprint

A stunning, dark-themed interactive hardware architecture diagram of the ATmega328P microcontroller (Arduino UNO) with elegant modern UI.

## Features

### 🎨 Modern Dark Design
- Sleek dark theme with gradient accents
- Elegant color-coded subsystems
- Professional engineering aesthetic
- Zero visual clutter
- Optimized text sizing - no overflow issues

### 🎯 Interactive Elements

- **Hover for Details**: Smooth tooltip appears at bottom showing component info
- **Click to Explore**: Opens elegant full-screen modal with:
  - Comprehensive technical details
  - **Interactive simulators** for hands-on learning
  - Arduino code examples
  - Performance specifications
  - Best practices and optimization tips

### 🎮 Interactive Simulators

#### 🧮 ALU Simulator
- **Live calculator**: Try ADD, SUB, AND, OR, XOR operations
- **Real-time flag updates**: See C, Z, N, V, H flags change
- **Multiple number formats**: View results in decimal, hex, and binary
- **Bit shift operations**: Experiment with LSL, LSR, ASR, ROL, ROR
- **Visual feedback**: Understand how each operation affects status flags

#### 📥 Instruction Fetch Simulator
- **Step-by-step animation**: Watch instruction fetch in action
- **Program Counter control**: Navigate through Flash memory
- **6-stage fetch sequence**: See each step of the fetch cycle
- **Real program examples**: Work with actual AVR instructions
- **Timing visualization**: Understand the 1-cycle fetch process

#### 🔍 Instruction Decoder Simulator
- **Interactive decoder**: Enter any 16-bit instruction
- **Binary breakdown**: See how opcodes are structured
- **Field extraction**: Understand Rd, Rr, K operands
- **Quick examples**: Try LDI, ADD, RET, JMP instructions
- **Opcode patterns**: Learn instruction formats

#### ⚙️ Control Unit Simulator
- **Signal generation**: See control signals for each instruction
- **Component coordination**: Understand how FSM orchestrates operations
- **Register control**: View read/write enable signals
- **ALU control**: See operation selection and routing
- **Memory control**: Understand data flow management
- **Timing details**: Learn execution cycles for different instructions

### 📊 Covered Components

#### CPU Core
- ✅ Program Counter
- ✅ ALU (Arithmetic Logic Unit) - Click for operation details
- ✅ Register File - 32 general-purpose registers with pointer details
- ✅ SREG Status Register with all 8 flags explained

#### Memory Subsystem
- ✅ Flash Memory (32KB) - Program storage with interrupt vectors
- ✅ SRAM (2KB) - Stack/heap layout and collision warnings
- ✅ EEPROM (1KB) - Non-volatile storage best practices

#### Peripherals
- ✅ **GPIO Ports B, C, D** - Pin configurations and special functions
- ✅ **Timer 0** - 8-bit timer for millis() and delay()
- ✅ **Timer 1** - 16-bit timer for Servo library
- ✅ **Timer 2** - 8-bit timer for tone() function
- ✅ **USART** - Serial communication with baud rate calculator
- ✅ **SPI** - High-speed serial interface
- ✅ **I2C/TWI** - Two-wire bus communication
- ✅ **ADC** - 10-bit analog-to-digital converter
- ✅ **Watchdog Timer** - System reset protection

#### System Features
- ✅ **Interrupt System** - 26 interrupt vectors with ISR best practices
- ✅ **Clock Distribution** - 16MHz crystal with prescalers
- ✅ **28-Pin DIP Package** - Complete pinout diagram

## Technical Accuracy

✅ All register addresses match the official Microchip ATmega328P datasheet  
✅ Bus widths are architecturally correct (16-bit program, 8-bit data)  
✅ SRAM address range starts at 0x0100 (not 0x0000)  
✅ 2-stage pipeline accurately represented  
✅ Harvard architecture clearly distinguished  

## Color Coding

- 🔵 **Blue**: CPU Core components
- 🟢 **Green**: Memory blocks
- 🟠 **Orange**: Peripheral subsystems
- 🔴 **Red**: Data buses and paths
- ⚫ **Gray**: Clock distribution

## Usage Tips

1. **Start with the overview**: Scroll through the entire diagram to understand the layout
2. **Hover for quick info**: See component names and brief descriptions
3. **Click for deep dive**: Open detailed modals with Arduino code examples
4. **Learn by exploring**: Each component has practical examples and optimization tips

## Educational Value

Perfect for:
- 🎓 **Computer Science Students**: Hands-on CPU architecture learning
- 💻 **Arduino Developers**: Understand how your code executes
- ⚡ **Embedded Engineers**: Deep dive into AVR internals
- 🔧 **Hardware Enthusiasts**: Interactive hardware exploration
- 📚 **Educators**: Visual teaching tool with live demonstrations
- 🧪 **Experimenters**: Try operations and see real-time results

## What Makes This Unique?

✨ **Not just a static diagram** - it's a full educational platform!

- **Interactive Calculators**: Actually perform ALU operations
- **Live Animations**: Watch instructions being fetched and decoded
- **Real Hardware Behavior**: Accurate simulations based on official datasheet
- **Hands-On Learning**: Experiment, don't just read
- **Beautiful Dark UI**: Modern, elegant, professional design
- **Zero Clutter**: Every pixel serves a purpose

## Technologies Used

- React + TypeScript
- Tailwind CSS
- SVG for scalable diagrams
- Lucide React icons

## Reference

Based on the official Microchip ATmega328P datasheet (Doc. 7810D–AVR–01/15)
